// "Color unquoted text as narration" is an Appearance option, off by default.
// Off, the formatter output is what it has always been. On, prose outside
// quotation marks takes the narration colour (`em.chat-italic`) and dialogue
// keeps the quote colour.
import { test, expect } from '@playwright/test';
import { openHarness } from './harness.js';

async function render(page, text, enabled) {
  return page.evaluate(
    async ([body, on]) => {
      const { Formatter } = await import(
        '/assets/chat_webview/formatter/formatter.js'
      );
      const formatter = new Formatter();
      formatter.setUnquotedAsNarration(on);
      const host = document.createElement('div');
      host.innerHTML = formatter.format(body, false, false, false);
      return {
        html: host.innerHTML,
        italic: Array.from(host.querySelectorAll('em.chat-italic')).map(
          (e) => e.textContent,
        ),
        quoted: Array.from(host.querySelectorAll('.chat-quote-text')).map(
          (e) => e.textContent,
        ),
      };
    },
    [text, enabled],
  );
}

test.describe('unquoted text as narration', () => {
  test.beforeEach(async ({ page }) => {
    await openHarness(page);
  });

  test('off by default: bare prose is not recoloured', async ({ page }) => {
    const out = await render(page, 'She smiles. "Hello." Then waves.', false);
    expect(out.italic).toEqual([]);
    expect(out.quoted).toEqual(['Hello.']);
  });

  test('on: prose outside quotes becomes narration, dialogue stays', async ({
    page,
  }) => {
    const out = await render(page, 'She smiles. "Hello." Then waves.', true);
    expect(out.italic).toEqual(['She smiles.', 'Then waves.']);
    expect(out.quoted).toEqual(['Hello.']);
  });

  test('on: text already in stars is not wrapped twice', async ({ page }) => {
    const out = await render(page, '*She smiles.* "Hello."', true);
    expect(out.italic).toEqual(['She smiles.']);
    expect(out.html).not.toContain('<em class="chat-italic"><em');
  });

  test('on: an unclosed quote while streaming stays dialogue', async ({
    page,
  }) => {
    const out = await render(page, 'She leans in. "I was', true);
    expect(out.italic).toEqual(['She leans in.']);
    expect(out.quoted).toEqual(['I was']);
  });

  test('on: code and headings are left alone', async ({ page }) => {
    const out = await render(page, '# Title\n\n`code` here', true);
    expect(out.html).toContain('<h1');
    expect(out.italic).not.toContain('Title');
    expect(out.italic).not.toContain('code');
  });
});
