import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/converters/reasoning_effort.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';
import 'package:glaze_flutter/features/settings/api_list_provider.dart';

void main() {
  group('endpoint drop-down', () {
    test('offers the new server first and keeps the old one second', () {
      expect(kApiServerChoices.length, 2);
      expect(kApiServerChoices.first.endpoint, kDefaultApiPresetEndpoint);
      expect(kDefaultApiPresetEndpoint, 'http://192.168.1.254:11434/v1');
      expect(kApiServerChoices.last.endpoint, kSecondApiPresetEndpoint);
      expect(kSecondApiPresetEndpoint, 'http://192.168.1.59:11434/v1');
    });

    test('a server is recognised however its address is typed', () {
      expect(
        apiServerChoiceFor('http://192.168.1.254:11434/v1/chat/completions'),
        kApiServerChoices.first,
      );
      expect(
        apiServerChoiceFor('192.168.1.254:11434'),
        kApiServerChoices.first,
      );
      expect(
        apiServerChoiceFor('HTTP://192.168.1.59:11434/v1'),
        kApiServerChoices.last,
      );
      expect(apiServerChoiceFor('https://api.openai.com/v1'), isNull);
      expect(apiServerChoiceFor(''), isNull);
    });

    test('host:port is read without the scheme or path', () {
      expect(apiServerKey('http://192.168.1.254:11434/v1'), '192.168.1.254:11434');
      expect(apiServerKey('localhost:11434/v1'), 'localhost:11434');
    });

    test('built-in presets start at the top reasoning effort', () {
      expect(kDefaultApiPresetReasoningEffort, 'max');
    });
  });

  group('reasoning depth (V67)', () {
    test('the steps still grow with the level', () {
      int words(String e) => PromptHelpers.thinkFirstWords(e).max;
      expect(words('low') < words('medium'), isTrue);
      expect(words('medium') < words('high'), isTrue);
      expect(words('high') < words('max'), isTrue);
      expect(nativeThinkingWordLimit('medium') < nativeThinkingWordLimit('high'),
          isTrue);
    });

    test('native limits stay inside their Think First range', () {
      for (final e in ['min', 'low', 'medium', 'high']) {
        expect(
          nativeThinkingWordLimit(e),
          greaterThanOrEqualTo(PromptHelpers.thinkFirstWords(e).max - 10),
          reason: e,
        );
      }
    });

    test('Think First text carries no unexpanded macros', () {
      for (final e in ['min', 'low', 'medium', 'high', 'max']) {
        expect(PromptHelpers.thinkFirstFor(e), isNot(contains('{{')));
        expect(PromptHelpers.planningInstruction(e), isNot(contains('{{')));
      }
    });

    test('token room covers the longest notes at each level', () {
      for (final e in ['medium', 'high', 'max']) {
        // About 1.4 tokens a word, plus room for the reply to start.
        final needed = (PromptHelpers.thinkFirstWords(e).max * 1.4).round();
        expect(PromptHelpers.thinkFirstExtraTokens(e), greaterThan(needed),
            reason: e);
      }
    });

    test('the planning step runs at a calmer temperature', () {
      expect(PromptHelpers.planTemperature, lessThanOrEqualTo(0.6));
    });
  });
}
