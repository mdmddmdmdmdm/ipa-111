/* Glaze – CrushOn Site Reader (in-page half).
 *
 * Injected at document start into a hidden WebView that is showing the real
 * crushon.ai site. It does NOT guess any API. It:
 *   1. drives the site's own UI (sort dropdown, date control, tags, search,
 *      favorites tab) exactly like a person would, and
 *   2. reads the cards the site renders, in the order the site renders them,
 *      scrolling the site's own infinite list for as long as needed, and
 *   3. passively records the JSON the site itself fetches so each card can be
 *      enriched with tags / counts / full-size art.
 *
 * Everything is exposed on window.__gzCO and is idempotent.
 */
(function () {
  'use strict';
  if (window.__gzCO && window.__gzCO.version >= 1) return;

  var S = {
    feed: [],            // ordered card records (the truth)
    map: new Map(),      // id -> record
    els: new Map(),      // id -> DOM element (last seen)
    raw: new Map(),      // any id-ish key -> raw JSON object the site fetched
    netOrder: [],        // ids in network arrival order (fallback only)
    netSet: new Set(),
    netSeq: 0,
    lastNetAt: 0,
    exhausted: false,
    parent: null,        // DOM parent of the feed's cards
    virtual: false,      // list recycles DOM nodes -> must scroll in small steps
    logs: []
  };

  function log(m) {
    try {
      S.logs.push(new Date().toISOString().slice(11, 19) + ' ' + m);
      if (S.logs.length > 250) S.logs.shift();
    } catch (e) {}
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function norm(s) {
    return String(s == null ? '' : s).toLowerCase()
      .replace(/[\u2018\u2019\u201B`\u00B4']/g, '')
      .replace(/[^a-z0-9]+/g, ' ').trim();
  }
  function ownText(el) {
    var t = '';
    try { t = (el.innerText || el.textContent || ''); } catch (e) {}
    return t.replace(/\s+/g, ' ').trim();
  }
  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs;
    try { cs = getComputedStyle(el); } catch (e) { return true; }
    if (cs.visibility === 'hidden' || cs.display === 'none') return false;
    if (parseFloat(cs.opacity) === 0) return false;
    return true;
  }

  // ---------------------------------------------------------------- network
  var IMG_KEYS = ['avatar', 'avatarUrl', 'avatar_url', 'image', 'imageUrl', 'image_url',
    'cover', 'coverUrl', 'poster', 'thumbnail', 'thumbnailUrl', 'picture', 'img',
    'photo', 'portrait', 'profileImage'];
  var TEXT_KEYS = ['introduction', 'greeting', 'brief', 'description', 'tags', 'personality'];

  function hasAny(o, keys) {
    for (var i = 0; i < keys.length; i++) {
      if (o[keys[i]] != null && o[keys[i]] !== '') return true;
    }
    return false;
  }
  function charLike(o) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
    var id = o.id != null ? o.id : (o.characterId != null ? o.characterId : o.uuid);
    var name = o.name != null ? o.name : (o.characterName != null ? o.characterName : o.title);
    if (id == null || typeof name !== 'string' || !name) return false;
    return hasAny(o, IMG_KEYS) || hasAny(o, ['introduction', 'greeting', 'brief']);
  }
  function idKeys(o) {
    var ks = [];
    ['id', 'characterId', 'uuid', 'slug'].forEach(function (k) {
      if (o[k] != null && o[k] !== '') ks.push(String(o[k]));
    });
    return ks;
  }
  function ingestJson(root) {
    var found = [], nodes = 0;
    (function walk(n, d) {
      if (n == null || d > 9 || nodes > 20000) return;
      nodes++;
      if (Array.isArray(n)) { for (var i = 0; i < n.length; i++) walk(n[i], d + 1); return; }
      if (typeof n !== 'object') return;
      if (charLike(n)) found.push(n);
      for (var k in n) {
        if (Object.prototype.hasOwnProperty.call(n, k)) {
          var v = n[k];
          if (v && typeof v === 'object') walk(v, d + 1);
        }
      }
    })(root, 0);
    if (!found.length) return 0;
    found.forEach(function (o) {
      var keys = idKeys(o);
      keys.forEach(function (k) {
        var ex = S.raw.get(k);
        if (!ex) { S.raw.set(k, o); return; }
        // Keep the richer object, but never lose fields.
        var merged = Object.assign({}, ex, o);
        S.raw.set(k, merged);
      });
      var primary = String(o.id != null ? o.id : (o.characterId != null ? o.characterId : o.uuid));
      if (hasAny(o, IMG_KEYS) && !S.netSet.has(primary)) {
        S.netSet.add(primary);
        S.netOrder.push(primary);
      }
    });
    S.netSeq++;
    S.lastNetAt = Date.now();
    return found.length;
  }
  function onBody(url, text) {
    try {
      if (!text || text.length > 6000000) return;
      var c = text.charCodeAt(0);
      while ((c === 32 || c === 10 || c === 13 || c === 9) && text.length) { text = text.slice(1); c = text.charCodeAt(0); }
      if (c !== 123 && c !== 91) return; // { or [
      var n = ingestJson(JSON.parse(text));
      if (n) log('net +' + n + ' <- ' + String(url).slice(0, 90));
    } catch (e) {}
  }
  function inspectable(url) {
    if (!url) return false;
    url = String(url);
    if (/\/_next\/static|\.(js|css|png|jpe?g|gif|webp|svg|woff2?|ico|mp4|webm)(\?|$)/i.test(url)) return false;
    return true;
  }
  try {
    var of = window.fetch;
    if (of && !of.__gz) {
      var nf = function (input) {
        var p = of.apply(this, arguments);
        try {
          var url = typeof input === 'string' ? input : (input && input.url) || '';
          if (inspectable(url)) {
            p.then(function (r) {
              try { r.clone().text().then(function (t) { onBody(url, t); }, function () {}); } catch (e) {}
            }, function () {});
          }
        } catch (e) {}
        return p;
      };
      nf.__gz = true;
      window.fetch = nf;
    }
    var XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
    if (!XO.__gz) {
      XMLHttpRequest.prototype.open = function (m, u) { this.__gzUrl = u; return XO.apply(this, arguments); };
      XMLHttpRequest.prototype.open.__gz = true;
      XMLHttpRequest.prototype.send = function () {
        var x = this;
        try {
          if (inspectable(x.__gzUrl)) {
            x.addEventListener('load', function () {
              try {
                if (x.responseType === '' || x.responseType === 'text') onBody(x.__gzUrl, x.responseText);
                else if (x.responseType === 'json' && x.response) ingestJson(x.response);
              } catch (e) {}
            });
          }
        } catch (e) {}
        return XS.apply(this, arguments);
      };
    }
  } catch (e) {}

  // ---------------------------------------------------------------- scanning
  var CHAR_RE = /\/characters?\/([^\/?#]+)/i;
  var BAD_IDS = { create: 1, 'new': 1, edit: 1, search: 1, list: 1 };
  function idFromHref(h) {
    if (!h) return null;
    var m = CHAR_RE.exec(h);
    if (!m) return null;
    var id;
    try { id = decodeURIComponent(m[1]); } catch (e) { id = m[1]; }
    if (!id || BAD_IDS[id.toLowerCase()]) return null;
    return id;
  }
  function inLandmark(el) {
    return !!(el.closest && el.closest('nav,aside,header,footer,[role=navigation],[role=dialog],[aria-modal=true]'));
  }
  function bestSrcFromImg(img) {
    var cands = [];
    var cs = img.currentSrc || '';
    if (cs) cands.push(cs);
    var ss = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
    if (ss) {
      var best = null, bw = -1;
      ss.split(',').forEach(function (part) {
        var p = part.trim().split(/\s+/);
        if (!p[0]) return;
        var w = parseFloat(p[1]) || 1;
        if (/x$/.test(p[1] || '')) w = parseFloat(p[1]) * 1000;
        if (w > bw) { bw = w; best = p[0]; }
      });
      if (best) cands.unshift(best);
    }
    ['src', 'data-src', 'data-lazy-src', 'data-original'].forEach(function (a) {
      var v = img.getAttribute(a);
      if (v) cands.push(v);
    });
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i];
      if (!c || /^data:image\/(gif|svg)/i.test(c) || /^blob:/i.test(c)) continue;
      if (/^data:/i.test(c) && c.length < 400) continue;
      return abs(c);
    }
    return '';
  }
  function abs(u) {
    try { return new URL(u, location.href).toString(); } catch (e) { return u; }
  }
  // next/image wraps the real CDN URL in /_next/image?url=ENCODED&w=..; the
  // wrapper is a *downscaled* copy, so prefer the original.
  function unwrapNextImage(u) {
    try {
      if (/\/_next\/image/.test(u)) {
        var q = new URL(u, location.href).searchParams.get('url');
        if (q) return abs(q);
      }
    } catch (e) {}
    return u;
  }
  function bgImageOf(el) {
    try {
      var all = [el].concat([].slice.call(el.querySelectorAll('*'), 0, 60));
      var best = '', ba = 0;
      for (var i = 0; i < all.length; i++) {
        var bg = getComputedStyle(all[i]).backgroundImage;
        if (bg && bg !== 'none') {
          var m = /url\((['"]?)(.*?)\1\)/.exec(bg);
          if (m && m[2] && !/^data:image\/svg/.test(m[2])) {
            var r = all[i].getBoundingClientRect();
            if (r.width * r.height >= ba) { ba = r.width * r.height; best = abs(m[2]); }
          }
        }
      }
      return best;
    } catch (e) { return ''; }
  }
  function lookupRaw(id, href) {
    var r = S.raw.get(id);
    if (r) return r;
    var m = CHAR_RE.exec(href || '');
    if (m && S.raw.get(m[1])) return S.raw.get(m[1]);
    return null;
  }

  function scanCards() {
    var anchors = [].slice.call(document.querySelectorAll('a[href]')).filter(function (a) {
      return idFromHref(a.getAttribute('href')) && !inLandmark(a) && visible(a);
    });
    if (!anchors.length) return [];
    var idCache = new Map();
    function idsIn(el) {
      var c = idCache.get(el);
      if (c) return c;
      var set = new Set();
      var as = el.querySelectorAll ? el.querySelectorAll('a[href]') : [];
      for (var i = 0; i < as.length; i++) {
        var id = idFromHref(as[i].getAttribute('href'));
        if (id) set.add(id);
      }
      idCache.set(el, set);
      return set;
    }
    var cardOf = new Map(); // cardEl -> {id, a}
    anchors.forEach(function (a) {
      var id = idFromHref(a.getAttribute('href'));
      var el = a;
      while (el.parentElement && el.parentElement !== document.body && el.parentElement !== document.documentElement) {
        var p = el.parentElement;
        if (idsIn(p).size > 1) break;
        el = p;
      }
      if (!cardOf.has(el)) cardOf.set(el, { id: id, a: a });
    });
    // group cards by parent: the feed is the biggest group.
    var groups = new Map();
    cardOf.forEach(function (v, el) {
      var p = el.parentElement;
      if (!groups.has(p)) groups.set(p, []);
      groups.get(p).push(el);
    });
    var bestP = null, bestN = -1, bestArea = -1;
    groups.forEach(function (els, p) {
      var area = 0;
      els.forEach(function (e) { var r = e.getBoundingClientRect(); area += r.width * r.height; });
      if (els.length > bestN || (els.length === bestN && area > bestArea)) { bestN = els.length; bestArea = area; bestP = p; }
    });
    S.parent = bestP;
    var cards = groups.get(bestP) || [];
    cards.sort(function (x, y) {
      if (x === y) return 0;
      var pos = x.compareDocumentPosition(y);
      return (pos & 4) ? -1 : 1; // x precedes y
    });
    var out = [];
    var seen = new Set();
    cards.forEach(function (el) {
      var meta = cardOf.get(el);
      if (!meta || seen.has(meta.id)) return;
      seen.add(meta.id);
      out.push(describeCard(el, meta));
    });
    return out;
  }

  function describeCard(el, meta) {
    var href = meta.a.getAttribute('href');
    var imgs = [].slice.call(el.querySelectorAll('img'));
    var bestImg = null, ba = -1;
    imgs.forEach(function (im) {
      var r = im.getBoundingClientRect();
      var a = r.width * r.height;
      if (a > ba) { ba = a; bestImg = im; }
    });
    var src = '', box = null, fit = '', pos = '', nat = null;
    if (bestImg) {
      src = unwrapNextImage(bestImg.currentSrc ? bestSrcFromImg(bestImg) : bestSrcFromImg(bestImg));
      var r = bestImg.getBoundingClientRect();
      box = [Math.round(r.width), Math.round(r.height)];
      try {
        var cs = getComputedStyle(bestImg);
        fit = cs.objectFit || '';
        pos = cs.objectPosition || '';
      } catch (e) {}
      if (bestImg.naturalWidth) nat = [bestImg.naturalWidth, bestImg.naturalHeight];
    }
    if (!src) {
      var bg = bgImageOf(el);
      if (bg) {
        src = unwrapNextImage(bg);
        var rr = el.getBoundingClientRect();
        box = box || [Math.round(rr.width), Math.round(rr.height)];
        fit = fit || 'cover';
      }
    }
    var vid = el.querySelector('video');
    if (!src && vid && vid.poster) src = abs(vid.poster);

    var name = '';
    var raw = lookupRaw(meta.id, href);
    if (raw) name = String(raw.name || raw.characterName || raw.title || '');
    if (!name) {
      var h = el.querySelector('h1,h2,h3,h4,h5,[class*="name" i],[class*="title" i]');
      if (h) name = ownText(h);
    }
    if (!name && bestImg && bestImg.alt) name = bestImg.alt;
    if (!name) name = meta.a.getAttribute('title') || meta.a.getAttribute('aria-label') || '';
    if (!name) name = (ownText(el).split('\n')[0] || '').slice(0, 80);
    return {
      id: meta.id, href: href, name: name, img: src,
      box: box, fit: fit, pos: pos, nat: nat, _el: el
    };
  }

  function mergeScan(cards) {
    var prevIdx = -1, added = 0;
    for (var i = 0; i < cards.length; i++) {
      var c = cards[i];
      S.els.set(c.id, c._el);
      var ex = S.map.get(c.id);
      if (ex) {
        if (!ex.img && c.img) ex.img = c.img;
        if ((!ex.name || ex.name.length < 2) && c.name) ex.name = c.name;
        if (c.box && (!ex.box || c.box[0] * c.box[1] > ex.box[0] * ex.box[1])) { ex.box = c.box; ex.fit = c.fit; ex.pos = c.pos; }
        if (c.nat && !ex.nat) ex.nat = c.nat;
        prevIdx = S.feed.indexOf(ex);
        continue;
      }
      var rec = { id: c.id, href: c.href, name: c.name, img: c.img, box: c.box, fit: c.fit, pos: c.pos, nat: c.nat };
      var idx = prevIdx + 1;
      if (prevIdx === -1 && S.feed.length > 0) {
        var later = -1;
        for (var j = i + 1; j < cards.length; j++) {
          var e2 = S.map.get(cards[j].id);
          if (e2) { later = S.feed.indexOf(e2); break; }
        }
        idx = later >= 0 ? later : S.feed.length;
      }
      S.feed.splice(idx, 0, rec);
      S.map.set(rec.id, rec);
      prevIdx = idx;
      added++;
    }
    return added;
  }
  function scan() { return mergeScan(scanCards()); }

  // ---------------------------------------------------------------- scrolling
  function getScroller() {
    if (!S.parent && S.scrollEl && S.scrollEl.isConnected) return S.scrollEl;
    var el = S.parent;
    while (el && el !== document.body && el !== document.documentElement) {
      var cs;
      try { cs = getComputedStyle(el); } catch (e) { break; }
      if (/(auto|scroll|overlay)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 40) { S.scrollEl = el; return el; }
      el = el.parentElement;
    }
    if (S.parent) S.scrollEl = null;
    return document.scrollingElement || document.documentElement;
  }
  function isRoot(sc) { return sc === document.scrollingElement || sc === document.documentElement || sc === document.body; }
  function scrollTop0() {
    var sc = getScroller();
    if (isRoot(sc)) window.scrollTo(0, 0); else sc.scrollTop = 0;
  }
  function fire(el, type) { try { el.dispatchEvent(new Event(type, { bubbles: true })); } catch (e) {} }
  function scrollDown() {
    var sc = getScroller();
    var lastId = S.feed.length ? S.feed[S.feed.length - 1].id : null;
    var lastEl = lastId ? S.els.get(lastId) : null;
    try { if (lastEl && lastEl.isConnected) lastEl.scrollIntoView({ block: 'end' }); } catch (e) {}
    if (isRoot(sc)) {
      window.scrollTo(0, Math.max(document.documentElement.scrollHeight, document.body.scrollHeight));
      fire(window, 'scroll');
    } else {
      sc.scrollTop = sc.scrollHeight;
      fire(sc, 'scroll');
    }
  }
  async function jiggle() {
    var sc = getScroller();
    if (isRoot(sc)) { window.scrollBy(0, -700); fire(window, 'scroll'); } else { sc.scrollTop = Math.max(0, sc.scrollTop - 700); fire(sc, 'scroll'); }
    await sleep(250);
    scrollDown();
  }

  // A virtualized list only keeps the rows near the viewport in the DOM, so a
  // jump to the bottom would skip everything in between. Detect it (rows we
  // already recorded have been detached) and switch to small, overlapping steps.
  function looksVirtual() {
    if (S.feed.length < 6) return false;
    var current = new Set(scanCards().map(function (c) { return c.id; }));
    var detached = 0, checked = 0;
    for (var i = 0; i < Math.min(8, S.feed.length); i++) {
      var id = S.feed[i].id, el = S.els.get(id);
      checked++;
      if (!current.has(id) && el && !el.isConnected) detached++;
    }
    return checked > 0 && detached >= Math.min(3, checked);
  }
  function stepDown(frac) {
    var sc = getScroller();
    var h = isRoot(sc) ? window.innerHeight : sc.clientHeight;
    var dy = Math.max(120, Math.round(h * frac));
    if (isRoot(sc)) { window.scrollBy(0, dy); fire(window, 'scroll'); }
    else { sc.scrollTop = sc.scrollTop + dy; fire(sc, 'scroll'); }
  }
  function atBottom() {
    var sc = getScroller();
    if (isRoot(sc)) return window.innerHeight + window.scrollY >= Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - 4;
    return sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4;
  }
  async function stepPump(target, deadline) {
    // Continue downward from the current position in overlapping steps.
    var stuck = 0;
    while (S.feed.length < target && Date.now() < deadline && !S.exhausted) {
      var before = S.feed.length, bn = S.netSeq, wasBottom = atBottom();
      stepDown(0.7);
      await sleep(190);
      scan();
      // overlap guard: if nothing we see is already known we may have skipped rows
      var cur = scanCards();
      if (S.feed.length && cur.length && !cur.some(function (c) { return S.map.has(c.id) && S.feed.indexOf(S.map.get(c.id)) >= S.feed.length - 40; }) && S.feed.length === before) {
        var sc2 = getScroller();
        if (isRoot(sc2)) window.scrollBy(0, -Math.round(window.innerHeight * 0.45)); else sc2.scrollTop = Math.max(0, sc2.scrollTop - Math.round(sc2.clientHeight * 0.45));
        await sleep(190); scan();
      }
      if (S.feed.length > before) { stuck = 0; continue; }
      if (wasBottom || atBottom()) {
        // at the end of what is loaded: give the site time to fetch more
        await waitGrowth(before, bn, 3200);
        if (S.feed.length > before) { stuck = 0; continue; }
        stuck++;
        if (stuck === 1) await jiggle();
        if (stuck >= 3) { S.exhausted = true; log('exhausted (virtual) at ' + S.feed.length); }
      } else {
        stuck++;
        if (stuck > 12) { S.exhausted = true; }
      }
    }
  }

  async function waitGrowth(before, beforeNet, timeout) {
    var t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      await sleep(160);
      scan();
      if (S.feed.length > before) { await sleep(120); scan(); return true; }
      if (S.netSeq !== beforeNet && Date.now() - S.lastNetAt > 450) {
        await sleep(200); scan();
        if (S.feed.length > before) return true;
      }
    }
    return false;
  }

  // ---------------------------------------------------------------- overlays
  function dismissOverlays() {
    var clicked = 0;
    try {
      var layers = [].slice.call(document.querySelectorAll(
        '[role=dialog],[aria-modal=true],[class*="modal" i],[class*="dialog" i],[class*="popup" i],[class*="overlay" i],[class*="gift" i]'));
      layers.forEach(function (layer) {
        if (!visible(layer)) return;
        if (layer.querySelector('[role=option],[role=menuitem],[role=listbox],[role=menu],[role=menuitemradio]')) return;
        var role = layer.getAttribute('role');
        if (role === 'menu' || role === 'listbox' || role === 'tooltip') return;
        var cs = getComputedStyle(layer), r = layer.getBoundingClientRect();
        var coverage = (r.width * r.height) / Math.max(1, innerWidth * innerHeight);
        var floating = cs.position === 'fixed' || cs.position === 'absolute' || role === 'dialog' || layer.getAttribute('aria-modal') === 'true';
        if (!floating || coverage < 0.12) return;
        if (layer.querySelectorAll('a[href*="/character/"]').length > 3) return;
        var btns = [].slice.call(layer.querySelectorAll('button,[role=button],a'));
        var closer = btns.find(function (b) {
          var t = norm(ownText(b)), al = norm(b.getAttribute('aria-label') || '');
          return /^(close|skip|no thanks|maybe later|not now|got it|dismiss|later|cancel|continue as guest|x)$/.test(t) ||
            /^(close|dismiss)$/.test(al) || ownText(b) === '\u00D7' || ownText(b) === '\u2715';
        });
        var txt = norm(ownText(layer));
        if (!closer && /(over 18|18 years|age verification|adult)/.test(txt)) {
          closer = btns.find(function (b) { return /^(i am over 18|im over 18|i am 18|enter|i agree|yes|confirm|continue)/.test(norm(ownText(b))); });
        }
        if (!closer && /(cookie|consent|privacy)/.test(txt)) {
          closer = btns.find(function (b) { return /^(accept all|accept|agree|allow all|ok|got it)$/.test(norm(ownText(b))); });
        }
        if (closer) { realClick(closer); clicked++; }
      });
    } catch (e) {}
    if (clicked) log('dismissed ' + clicked + ' overlay(s)');
    return clicked;
  }

  // ---------------------------------------------------------------- clicking
  function realClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
    var r = el.getBoundingClientRect();
    var x = r.left + r.width / 2, y = r.top + r.height / 2;
    var P = window.PointerEvent || MouseEvent;
    function mk(type, C, buttons, extra) {
      var init = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0, buttons: buttons };
      if (extra) for (var k in extra) init[k] = extra[k];
      try { el.dispatchEvent(new C(type, init)); } catch (e) {}
    }
    var pe = { pointerType: 'mouse', isPrimary: true, pointerId: 1 };
    mk('pointerover', P, 0, pe); mk('mouseover', MouseEvent, 0);
    mk('pointerdown', P, 1, pe); mk('mousedown', MouseEvent, 1);
    try { if (el.focus) el.focus({ preventScroll: true }); } catch (e) {}
    mk('pointerup', P, 0, pe); mk('mouseup', MouseEvent, 0);
    mk('click', MouseEvent, 0);
    return true;
  }
  function isControl(el) {
    var role = el.getAttribute && el.getAttribute('role');
    var tag = (el.tagName || '').toLowerCase();
    return /^(button|a|select|summary|label|input)$/.test(tag) ||
      /^(option|menuitem|menuitemradio|menuitemcheckbox|button|tab|switch|radio|checkbox|combobox)$/.test(role || '') ||
      !!(el.getAttribute && el.getAttribute('aria-haspopup'));
  }
  function clickableAncestor(el) {
    if (el && !isControl(el) && el.querySelectorAll) {
      var inner = [].slice.call(el.querySelectorAll('button,[role=button],[role=tab],[role=switch],a[href],[aria-haspopup]')).filter(visible);
      if (inner.length === 1) return inner[0];
    }
    var cur = el;
    for (var i = 0; i < 6 && cur; i++) {
      var role = cur.getAttribute && cur.getAttribute('role');
      var tag = (cur.tagName || '').toLowerCase();
      if (/^(button|a|li|label|summary)$/.test(tag) || /^(option|menuitem|menuitemradio|menuitemcheckbox|button|tab|switch|radio|checkbox)$/.test(role || '')) return cur;
      if (cur.onclick || (getComputedStyle(cur).cursor === 'pointer')) return cur;
      cur = cur.parentElement;
    }
    return el;
  }
  function inCard(el) {
    var a = el.closest && el.closest('a[href]');
    return !!(a && idFromHref(a.getAttribute('href')));
  }
  function setNativeValue(input, value) {
    var tag = (input.tagName || '').toUpperCase();
    var proto = tag === 'TEXTAREA' ? HTMLTextAreaElement.prototype
      : tag === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // All visible elements whose own text normalises to one of `labels`.
  function findByText(labels, opts) {
    opts = opts || {};
    var want = labels.map(norm);
    var sel = opts.selector || 'button,[role=button],[role=option],[role=menuitem],[role=menuitemradio],[role=tab],[role=combobox],[aria-haspopup],li,a,label,div,span,p';
    var out = [];
    [].slice.call(document.querySelectorAll(sel)).forEach(function (el) {
      if (!visible(el) || inCard(el)) return;
      var t = norm(ownText(el));
      if (!t || t.length > 40) return;
      if (want.indexOf(t) >= 0) out.push(el);
    });
    // keep only the deepest match of any ancestor chain
    return out.filter(function (el) {
      return !out.some(function (o) { return o !== el && el.contains(o); });
    });
  }

  // ---------------------------------------------------------------- sort
  var SORT_ALIASES = {
    'popular': ['popular', 'most popular'],
    'recent_hits': ['recent hits', 'recent hit', 'recent'],
    'trending': ['trending'],
    'new': ['new', 'newest', 'latest'],
    'daily_ranking': ['daily ranking', 'daily rank', 'daily'],
    'editor_choice': ['editors choice', 'editor choice', 'editors pick', 'editors'],
    'following': ['following']
  };
  var ALL_SORT_LABELS = [];
  Object.keys(SORT_ALIASES).forEach(function (k) { ALL_SORT_LABELS = ALL_SORT_LABELS.concat(SORT_ALIASES[k]); });

  function topFirst(a, b) { return a.getBoundingClientRect().top - b.getBoundingClientRect().top; }

  function findSortTrigger() {
    var sels = document.querySelectorAll('select');
    for (var i = 0; i < sels.length; i++) {
      if (!visible(sels[i])) continue;
      var opts = [].slice.call(sels[i].options).map(function (o) { return norm(o.text); });
      if (opts.filter(function (o) { return ALL_SORT_LABELS.indexOf(o) >= 0; }).length >= 2) return { kind: 'select', el: sels[i] };
    }
    var els = findByText(ALL_SORT_LABELS).filter(function (el) {
      // not an option inside an open list
      return !el.closest('[role=listbox],[role=menu],[data-radix-popper-content-wrapper]');
    });
    els.sort(topFirst);
    for (var j = 0; j < els.length; j++) {
      var c = clickableAncestor(els[j]);
      if (c && visible(c)) return { kind: 'click', el: c, label: ownText(els[j]) };
    }
    return null;
  }
  function currentSortKey() {
    var t = findSortTrigger();
    if (!t) return null;
    var label = t.kind === 'select' ? t.el.options[t.el.selectedIndex].text : (t.label || ownText(t.el));
    var n = norm(label);
    for (var k in SORT_ALIASES) if (SORT_ALIASES[k].indexOf(n) >= 0) return { key: k, label: label };
    return { key: null, label: label };
  }
  function discoverSortOptions() {
    var found = [];
    var cands = [].slice.call(document.querySelectorAll('[role=option],[role=menuitem],[role=menuitemradio],[role=listbox] *,[role=menu] *,[data-radix-popper-content-wrapper] *,li'));
    cands.forEach(function (el) {
      if (!visible(el)) return;
      var t = norm(ownText(el));
      if (ALL_SORT_LABELS.indexOf(t) >= 0 && found.indexOf(ownText(el)) < 0) found.push(ownText(el));
    });
    return found;
  }

  async function applySort(key) {
    var aliases = SORT_ALIASES[key] || [norm(key)];
    var steps = [];
    dismissOverlays();
    var trig = findSortTrigger();
    if (!trig) {
      steps.push('no sort control found');
      return { ok: false, reason: 'no-sort-control', steps: steps, controls: describeControls() };
    }
    var cur = currentSortKey();
    steps.push('current=' + (cur && cur.label));
    if (cur && cur.key === key) return { ok: true, label: cur.label, changed: false, steps: steps };

    if (trig.kind === 'select') {
      var sel = trig.el, idx = -1;
      for (var i = 0; i < sel.options.length; i++) if (aliases.indexOf(norm(sel.options[i].text)) >= 0) idx = i;
      if (idx < 0) return { ok: false, reason: 'option-missing', steps: steps };
      markAction();
      setNativeValue(sel, sel.options[idx].value);
      steps.push('select -> ' + sel.options[idx].text);
      return { ok: true, label: sel.options[idx].text, changed: true, steps: steps };
    }

    var optionEl = null;
    function lookOption() {
      var matches = findByText(aliases).filter(function (el) { return el !== trig.el && !trig.el.contains(el) && !el.contains(trig.el); });
      // prefer ones inside a popup/list
      var inPop = matches.filter(function (el) { return el.closest('[role=listbox],[role=menu],[data-radix-popper-content-wrapper],[class*="dropdown" i],[class*="menu" i],[class*="popover" i],[class*="select" i]'); });
      return (inPop[0] || matches[0]) || null;
    }
    for (var attempt = 0; attempt < 3 && !optionEl; attempt++) {
      if (attempt === 0) realClick(trig.el);
      else if (attempt === 1) { try { trig.el.click(); } catch (e) {} }
      else {
        try { trig.el.focus(); } catch (e) {}
        ['keydown', 'keyup'].forEach(function (t) { trig.el.dispatchEvent(new KeyboardEvent(t, { key: 'ArrowDown', code: 'ArrowDown', bubbles: true })); });
      }
      for (var w = 0; w < 8 && !optionEl; w++) { await sleep(120); optionEl = lookOption(); }
      steps.push('open attempt ' + attempt + (optionEl ? ' ok' : ' no-option'));
    }
    if (!optionEl) {
      return { ok: false, reason: 'option-not-found', steps: steps, options: discoverSortOptions(), controls: describeControls() };
    }
    var options = discoverSortOptions();
    var target = clickableAncestor(optionEl);
    markAction();
    realClick(target);
    steps.push('clicked ' + ownText(optionEl));
    await sleep(250);
    return { ok: true, label: ownText(optionEl), changed: true, steps: steps, options: options };
  }

  // after any UI action: wait until the feed visibly changes and goes quiet.
  function sigNow() {
    var cs = scanCards();
    return cs.slice(0, 8).map(function (c) { return c.id; }).join(',');
  }
  async function settle(prevSig, maxMs) {
    var t0 = Date.now(), changed = false;
    while (Date.now() - t0 < maxMs) {
      await sleep(200);
      var s = sigNow();
      if (s && s !== prevSig) { changed = true; }
      var quiet = Date.now() - S.lastNetAt > 700;
      if (changed && quiet) { await sleep(300); return { changed: true }; }
    }
    return { changed: changed };
  }

  // ---------------------------------------------------------------- date
  var MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoOf(y, m, d) { return y + '-' + pad(m) + '-' + pad(d); }
  function inferYear(m, d) {
    var now = new Date(), y = now.getFullYear();
    if (new Date(y, m - 1, d).getTime() > now.getTime() + 86400000 * 2) y -= 1;
    return y;
  }
  function parseDateText(t) {
    t = String(t || '');
    var m = /(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/.exec(t);
    if (m) return isoOf(+m[1], +m[2], +m[3]);
    var mon = '(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?';
    m = new RegExp('\\b' + mon + '\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?', 'i').exec(t);
    if (m) { var mi = MONTHS.indexOf(m[1].toLowerCase()) + 1; return isoOf(m[3] ? +m[3] : inferYear(mi, +m[2]), mi, +m[2]); }
    m = new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+' + mon + '(?:,?\\s+(\\d{4}))?', 'i').exec(t);
    if (m) { var mj = MONTHS.indexOf(m[2].toLowerCase()) + 1; return isoOf(m[3] ? +m[3] : inferYear(mj, +m[1]), mj, +m[1]); }
    m = /\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/.exec(t);
    if (m && +m[1] <= 12 && +m[2] <= 31) { var yy = m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : inferYear(+m[1], +m[2]); return isoOf(yy, +m[1], +m[2]); }
    return null;
  }
  function findDateControl() {
    var inputs = [].slice.call(document.querySelectorAll('input[type=date]'));
    if (inputs.length) return { kind: 'native', el: inputs[0] };
    var cands = [].slice.call(document.querySelectorAll('button,[role=button],[aria-haspopup],div,span,a,input'));
    var hits = [];
    cands.forEach(function (el) {
      if (!visible(el) || inCard(el) || el.closest('[role=dialog],[role=grid],table')) return;
      var t = el.tagName === 'INPUT' ? el.value : ownText(el);
      if (!t || t.length > 28) return;
      if (parseDateText(t)) hits.push(el);
    });
    if (!hits.length) {
      var byAria = [].slice.call(document.querySelectorAll('[aria-label*="calendar" i],[aria-label*="date" i],[aria-label*="day" i]')).filter(function (e) { return visible(e) && !inCard(e); });
      if (byAria.length) return { kind: 'click', el: clickableAncestor(byAria[0]), label: ownText(byAria[0]) };
      return null;
    }
    hits.sort(function (a, b) {
      var ca = isControl(a) ? 0 : 1, cb = isControl(b) ? 0 : 1;
      if (ca !== cb) return ca - cb;
      return a.getBoundingClientRect().width * a.getBoundingClientRect().height - b.getBoundingClientRect().width * b.getBoundingClientRect().height;
    });
    var el = hits[0];
    return { kind: 'click', el: clickableAncestor(el), label: el.tagName === 'INPUT' ? el.value : ownText(el) };
  }
  function readDate() {
    var c = findDateControl();
    if (!c) return { has: false };
    if (c.kind === 'native') {
      return { has: true, kind: 'native', label: c.el.value || '', iso: c.el.value || null, min: c.el.min || null, max: c.el.max || null };
    }
    return { has: true, kind: 'click', label: c.label || '', iso: parseDateText(c.label) };
  }
  function monthYearOfHeader(root) {
    var txt = ownText(root);
    var m = /(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})/i.exec(txt);
    if (!m) return null;
    var mi = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'].indexOf(m[1].toLowerCase()) + 1;
    return { y: +m[2], m: mi };
  }
  async function applyDate(iso) {
    var parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!parts) return { ok: false, reason: 'bad-date' };
    var Y = +parts[1], M = +parts[2], D = +parts[3];
    var c = findDateControl();
    if (!c) return { ok: false, reason: 'no-date-control' };
    if (c.kind === 'native') {
      if ((c.el.min && iso < c.el.min) || (c.el.max && iso > c.el.max)) return { ok: false, reason: 'out-of-range', min: c.el.min, max: c.el.max };
      markAction();
      setNativeValue(c.el, iso);
      return { ok: true, kind: 'native' };
    }
    if (parseDateText(c.label) === iso) return { ok: true, kind: 'click', unchanged: true };
    realClick(c.el);
    await sleep(350);
    for (var step = 0; step < 30; step++) {
      var pop = document.querySelector('[role=dialog],[role=grid],.react-datepicker,.rdp,[class*="calendar" i],[class*="datepicker" i],[class*="date-picker" i]');
      if (!pop || !visible(pop)) { await sleep(150); if (step > 6) break; continue; }
      var root = pop.closest('[role=dialog]') || pop;
      var hdr = monthYearOfHeader(root);
      if (hdr && (hdr.y !== Y || hdr.m !== M)) {
        var wantBack = (hdr.y * 12 + hdr.m) > (Y * 12 + M);
        var navBtns = [].slice.call(root.querySelectorAll('button,[role=button]'));
        var nav = navBtns.find(function (b) {
          var al = norm((b.getAttribute('aria-label') || '') + ' ' + ownText(b) + ' ' + (b.className || ''));
          return wantBack ? /(prev|previous|back|left|chevron left)/.test(al) : /(next|forward|right|chevron right)/.test(al);
        });
        if (!nav) { // fall back to first/last button in the header
          var bs = navBtns.filter(function (b) { return !/^\d{1,2}$/.test(ownText(b)); });
          nav = wantBack ? bs[0] : bs[bs.length - 1];
        }
        if (!nav) return { ok: false, reason: 'no-month-nav' };
        realClick(nav); await sleep(200); continue;
      }
      var cells = [].slice.call(root.querySelectorAll('button,[role=gridcell],td,[role=button],div')).filter(function (el) {
        if (!visible(el)) return false;
        var t = ownText(el);
        var al = el.getAttribute('aria-label') || '';
        if (al) {
          var p = parseDateText(al);
          if (p === iso) return true;
        }
        return t === String(D) && el.children.length <= 1;
      });
      var good = cells.filter(function (el) {
        var cls = String(el.className || '') + ' ' + String(el.parentElement && el.parentElement.className || '');
        return !el.disabled && el.getAttribute('aria-disabled') !== 'true' && !/(disabled|outside|muted|unavailable)/i.test(cls);
      });
      if (!good.length) return { ok: false, reason: 'day-unavailable' };
      markAction();
      realClick(clickableAncestor(good[0]));
      await sleep(250);
      // some pickers need an explicit confirm button
      var confirm = [].slice.call(root.querySelectorAll('button')).find(function (b) { return /^(ok|apply|done|confirm|select)$/.test(norm(ownText(b))); });
      if (confirm) realClick(confirm);
      return { ok: true, kind: 'click' };
    }
    return { ok: false, reason: 'calendar-not-found' };
  }

  // ---------------------------------------------------------------- nsfw/tags
  function stateOf(el) {
    var cur = el;
    for (var i = 0; i < 4 && cur; i++) {
      var ap = cur.getAttribute && (cur.getAttribute('aria-pressed') || cur.getAttribute('aria-checked') || cur.getAttribute('aria-selected'));
      if (ap === 'true') return true;
      if (ap === 'false') return false;
      var ds = cur.getAttribute && cur.getAttribute('data-state');
      if (ds && /^(on|checked|active|selected|open)$/i.test(ds)) return true;
      if (ds && /^(off|unchecked|inactive)$/i.test(ds)) return false;
      var inp = cur.querySelector && cur.querySelector('input[type=checkbox],input[type=radio]');
      if (inp) return !!inp.checked;
      var cls = String(cur.className || '');
      if (/(^|[\s_-])(active|selected|checked|enabled|on)([\s_-]|$)/i.test(cls)) return true;
      cur = cur.parentElement;
    }
    return null;
  }
  async function applyNsfw(want) {
    var els = findByText(['unfiltered', 'nsfw']);
    els.sort(topFirst);
    for (var i = 0; i < els.length; i++) {
      var tgt = clickableAncestor(els[i]);
      var st = stateOf(tgt);
      if (st === null) continue;
      if (st === !!want) return { ok: true, state: st, changed: false };
      var prev = sigNow();
      markAction();
      realClick(tgt);
      await sleep(350);
      var after = stateOf(tgt);
      await settle(prev, 6000);
      return { ok: after === !!want, state: after, changed: true };
    }
    return { ok: false, state: null, reason: 'toggle-state-unknown' };
  }
  async function applyTags(tags) {
    var applied = [], missing = [];
    for (var i = 0; i < tags.length; i++) {
      var tag = tags[i];
      var found = findByText([tag])[0];
      if (!found) {
        var opener = findByText(['filter', 'filters', 'tags', 'tag', 'all tags', 'more'])[0];
        if (opener) { realClick(clickableAncestor(opener)); await sleep(350); found = findByText([tag])[0]; }
      }
      if (!found) { missing.push(tag); continue; }
      var st = stateOf(clickableAncestor(found));
      if (st === true) { applied.push(tag); continue; }
      var prev = sigNow();
      markAction();
      realClick(clickableAncestor(found));
      await settle(prev, 6000);
      applied.push(tag);
    }
    return { applied: applied, missing: missing };
  }

  // ---------------------------------------------------------------- search / account
  async function typeSearch(query) {
    var inputs = [].slice.call(document.querySelectorAll('input[type=search],input[type=text],input:not([type]),input[placeholder*="search" i]')).filter(visible);
    var input = inputs.find(function (i) { return /search/i.test((i.placeholder || '') + (i.getAttribute('aria-label') || '') + (i.type || '') + (i.name || '')); }) || inputs[0];
    if (!input) return { ok: false, reason: 'no-search-input', controls: describeControls() };
    var prev = sigNow();
    markAction();
    input.focus();
    setNativeValue(input, query);
    await sleep(150);
    ['keydown', 'keypress', 'keyup'].forEach(function (t) {
      input.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    });
    var form = input.closest('form');
    if (form) { try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch (e) {} }
    var res = await settle(prev, 9000);
    return { ok: true, changed: res.changed };
  }
  var FAV_RE = /^(my )?(favou?rites?|favou?rited|liked|saved|starred|collection|bookmarks?)( \d+)?$/;
  async function openFavorites() {
    var all = [].slice.call(document.querySelectorAll('button,[role=tab],[role=button],a,li,div,span')).filter(function (el) {
      return visible(el) && !inCard(el) && FAV_RE.test(norm(ownText(el))) && ownText(el).length < 30;
    });
    all.sort(function (a, b) { return a.getBoundingClientRect().width * a.getBoundingClientRect().height - b.getBoundingClientRect().width * b.getBoundingClientRect().height; });
    if (!all.length) {
      // Menus are often collapsed behind a hamburger / "Open sidebar" button.
      var burger = [].slice.call(document.querySelectorAll('button,[role=button],a,div')).filter(function (el) {
        return visible(el) && /(open sidebar|menu|sidebar|navigation)/i.test((el.getAttribute('aria-label') || '') + ' ' + (el.title || '') + ' ' + (ownText(el).length < 20 ? ownText(el) : ''));
      });
      for (var b = 0; b < Math.min(2, burger.length) && !all.length; b++) {
        realClick(clickableAncestor(burger[b]));
        await sleep(450);
        all = [].slice.call(document.querySelectorAll('button,[role=tab],[role=button],a,li,div,span')).filter(function (el) {
          return visible(el) && !inCard(el) && FAV_RE.test(norm(ownText(el))) && ownText(el).length < 30;
        });
      }
    }
    if (!all.length) return { ok: false, reason: 'no-favorites-tab', controls: describeControls() };
    all.sort(function (a, b) { return a.getBoundingClientRect().width * a.getBoundingClientRect().height - b.getBoundingClientRect().width * b.getBoundingClientRect().height; });
    var prev = sigNow();
    markAction();
    realClick(clickableAncestor(all[0]));
    var r = await settle(prev, 9000);
    return { ok: true, changed: r.changed, label: ownText(all[0]) };
  }
  function describeControls() {
    var out = [];
    [].slice.call(document.querySelectorAll('button,[role=tab],[role=button],[role=option],[role=menuitem],a,select,input')).forEach(function (el) {
      if (!visible(el) || inCard(el)) return;
      var t = (el.tagName === 'INPUT' ? ('input:' + (el.placeholder || el.type)) : ownText(el)).slice(0, 36);
      if (t && out.indexOf(t) < 0) out.push(t);
    });
    return out.slice(0, 70);
  }

  // ---------------------------------------------------------------- public API
  function pageInfo() {
    var title = document.title || '';
    var cf = /just a moment|attention required|verify you are human/i.test(title) ||
      !!document.querySelector('#challenge-form,.cf-turnstile,iframe[src*="challenges.cloudflare"],#cf-challenge-running');
    var loggedOut = !!([].slice.call(document.querySelectorAll('a[href*="/auth/signin"],a[href*="/login"],a[href*="/signin"]')).find(visible)) ||
      !!findByText(['log in', 'sign in', 'login']).filter(function (e) { return !e.closest('[role=dialog]'); }).length;
    return { href: location.href, title: title, cf: cf, loggedOut: loggedOut, cards: scanCards().length, ready: document.readyState };
  }

  function resetFeed() {
    S.feed = []; S.map = new Map(); S.els = new Map();
    S.exhausted = false; S.parent = null;
  }
  // Called right before a UI action that will make the site load a new list.
  function markAction() { S.netOrder = []; S.netSet = new Set(); }
  function resetFeedKeepMode() { var v = S.virtual; resetFeed(); S.virtual = v; }

  function shapeRaw(r) {
    if (!r) return null;
    var out = {};
    for (var k in r) {
      if (!Object.prototype.hasOwnProperty.call(r, k)) continue;
      var v = r[k];
      if (typeof v === 'string' && v.length > 20000) v = v.slice(0, 20000);
      out[k] = v;
    }
    return out;
  }
  function snapshot(from, to) {
    var recs = S.feed;
    var source = 'dom';
    if (!recs.length && S.netOrder.length) {
      source = 'net';
      recs = S.netOrder.map(function (id) {
        var r = S.raw.get(id) || {};
        return { id: id, href: '/character/' + id, name: String(r.name || r.characterName || r.title || id), img: '', box: null, fit: '', pos: '', nat: null };
      });
    }
    var slice = recs.slice(from, to).map(function (c) {
      return { id: c.id, href: c.href, name: c.name, img: c.img, box: c.box, fit: c.fit, pos: c.pos, nat: c.nat, raw: shapeRaw(lookupRaw(c.id, c.href)) };
    });
    return { items: slice, total: recs.length, exhausted: S.exhausted, source: source };
  }
  async function fillImages(from, to) {
    var missing = S.feed.slice(from, to).filter(function (r) { return !r.img; });
    for (var i = 0; i < missing.length && i < 40; i++) {
      var el = S.els.get(missing[i].id);
      if (el && el.isConnected) {
        try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
        await sleep(140);
        scan();
      }
    }
  }

  async function pump(from, target, maxMs) {
    var t0 = Date.now();
    dismissOverlays();
    if (!S.feed.length) { scrollTop0(); await sleep(350); }
    scan();
    var stagn = 0;
    while (S.feed.length < target && Date.now() - t0 < maxMs && !S.exhausted) {
      if (S.virtual) { await stepPump(target, t0 + maxMs); break; }
      var before = S.feed.length, bn = S.netSeq;
      scrollDown();
      await waitGrowth(before, bn, 3200);
      if (S.feed.length > before) {
        stagn = 0;
        if (looksVirtual()) {
          // we probably skipped rows: restart from the top in small steps
          log('virtual list detected -> stepwise re-collect');
          S.virtual = true;
          var keepRaw = S.raw;
          resetFeed(); S.virtual = true; S.raw = keepRaw;
          scrollTop0(); await sleep(400); scan();
        }
        continue;
      }
      stagn++;
      if (stagn === 1) await jiggle();
      if (stagn >= 3) { S.exhausted = true; log('exhausted at ' + S.feed.length); }
    }
    scan();
    await fillImages(from, target);
    return snapshot(from, target);
  }

  async function prepareFeed() {
    // call after any UI change: forget old cards, start from a clean top.
    resetFeedKeepMode();
    scrollTop0();
    await sleep(350);
    scan();
    return { cards: S.feed.length };
  }

  function pageData() {
    var nd = document.getElementById('__NEXT_DATA__');
    function meta(p) {
      var m = document.querySelector('meta[property="' + p + '"],meta[name="' + p + '"]');
      return m ? m.getAttribute('content') : '';
    }
    var raws = [];
    S.raw.forEach(function (v, k) { if (raws.indexOf(v) < 0) raws.push(v); });
    return {
      href: location.href, title: document.title,
      nextData: nd ? nd.textContent.slice(0, 600000) : null,
      og: { title: meta('og:title'), description: meta('og:description'), image: meta('og:image') },
      netSeq: S.netSeq, netQuietMs: Date.now() - (S.lastNetAt || 0),
      raws: raws.slice(-60).map(shapeRaw),
      text: ownText(document.body).slice(0, 8000)
    };
  }

  window.__gzCO = {
    version: 1,
    state: S,
    log: log, logs: function () { return S.logs.slice(-80); },
    pageInfo: pageInfo, scan: scan, resetFeed: resetFeed, prepareFeed: prepareFeed, markAction: markAction,
    pump: pump, snapshot: snapshot,
    currentSort: currentSortKey, discoverSortOptions: discoverSortOptions, applySort: applySort,
    readDate: readDate, applyDate: applyDate,
    applyNsfw: applyNsfw, applyTags: applyTags,
    typeSearch: typeSearch, openFavorites: openFavorites,
    pageData: pageData, describeControls: describeControls,
    dismissOverlays: dismissOverlays, settle: settle, sigNow: sigNow,
    _norm: norm, _parseDateText: parseDateText, _findDateControl: findDateControl
  };
})();
