<p align="center">
  <img src="assets/logos/glaze.png" width="256" alt="Glaze Logo">
</p>

# Glaze

[![Download](https://img.shields.io/github/v/release/hydall/Glaze?include_prereleases&label=download&color=C42A4A)](https://github.com/hydall/Glaze/releases/latest)
[![Discord](https://img.shields.io/badge/Discord-Join-5865F2?style=flat&logo=discord&logoColor=white)](https://discord.gg/jnGhd7p6Ht)
[![Buy Me A Coffee](https://img.shields.io/badge/Buy%20Me%20A%20Coffee-FFDD00?style=flat&logo=buy-me-a-coffee&logoColor=black)](https://buymeacoffee.com/hydall)

[Русский](README.ru.md)

Glaze is a local, user-friendly AI roleplay chat client. It works with any OpenAI-compatible (Chat Completion) LLM provider, and keeps your data on your own device.

> [!WARNING]
> Glaze is still under heavy development. The app is not yet stable and may contain bugs.
>
> 🧪 **Disclaimer**: This app was **vibecoded** using a plethora of models. Curb your expectations.

## ✨ Key Features

- **User-Friendly Installation and Interface** — You don't need an IT degree to use the app. Just install it and start chatting.
- **Actually Working User Statistics** — Gain insights into how many messages you've sent, how many tokens you've burned, and how many hours you've spent chatting.
- **Native Reasoning Model Support** — No complex regex needed. Native reasoning is properly parsed and injected into a separate block that is not sent back to the model. If your preset has its own reasoning tags, Glaze can parse those too.
- **Customizable Theming** — Change colors, fonts, and background images, then export your theme as a JSON file to share with others. Material 3 throughout, with separate desktop and mobile layouts.
- **Background Generation** — Glaze can generate responses in the background and notify you once they are ready.
- **Lorebooks and Memory** — Attach lorebooks, memory books, author's notes, and personas to keep long-running roleplay coherent.
- **Image Generation** — Generate images from inside the app and wire image output into roleplay flows and extension blocks.
- **Cloud Sync** — Optional Dropbox and Google Drive sync for moving your local data between devices.
- **Local-First Storage** — Characters, sessions, presets, API configuration, personas, lorebooks, and extension data all live in a local SQLite database.
- **Extensions (ExtBlocks)** — Automate post-generation actions: info blocks, image generation, JS scripts, and interactive HTML panels. *(under development)*
- **Glaze Studio** — A multi-agent pipeline for improving response quality: cleanup, fact-checking, entity tracking, and constraint enforcement. *(under development)*

## 🤝 Basic SillyTavern Compatibility

- **Presets** — All JSON presets from SillyTavern are compatible with Glaze. Several popular presets come preinstalled.
- **Advanced Macro System** — Basic macro support is available (full SillyTavern compatibility is in progress). Variables (setvars/getvars), random choices, dice rolls, and character/user data substitution are fully supported.
- **Character Card Compatibility** — Import and export character cards in SillyTavern V2 format (JSON and PNG).
- **Lorebooks (World Info)** — Full support for lorebooks to enhance your roleplay experience.
- **Regex Support** — Full support for regex scripts, including those built into your favorite presets.

## 🧩 Extensions

Glaze includes a sandboxed extension system for post-generation automation and interactive UI blocks.

- **Post-generation blocks** — Run `infoblock`, `imageGen`, `jsRunner`, and `interactive` blocks after assistant messages and after user messages.
- **Interactive panels** — Render extension-owned HTML panels under assistant messages without giving scripts same-origin access to the app.
- **JS extension SDK** — Sandboxed scripts can use `window.glaze.*` APIs for variables, text generation, prompt injection, audio, command execution, toasts, and more.
- **Capability permissions** — Every bridge method is gated by explicit per-preset capabilities. The default is deny.
- **Scoped variables** — Extensions can use `chat`, `character`, `global`, and `message` variable scopes through dedicated storage APIs.

See `docs/ARCHITECTURE.md` section 9 and `docs/INVARIANTS.md` for the bridge architecture and security invariants.

## 📥 Installation

Download the latest release from the [Releases](https://github.com/hydall/Glaze/releases/latest) page.

- **Android** — Install the APK directly on your device.
- **iOS** — Sideload the IPA using [AltStore](https://altstore.io/) or a similar tool. App Store distribution is not yet available.
- **Windows** — Download the Windows build and run it directly on your PC.
- **Linux** — Install the pacman package on Arch-based distros (it pulls in WPE WebKit), or unpack the `.tar.zst` archive on another rolling distro with WPE WebKit installed. Ubuntu and Debian are not supported yet: they do not package WPE WebKit.
- **macOS** — Buildable from source, but not currently published as a prebuilt release.

Backups from **SillyTavern** (`.zip`) can be imported via **Menu → Backups**.

## 🛠️ Contributing

Glaze is built with Flutter, using local SQLite storage, native desktop support, and a sandboxed extension runtime. Powered by Riverpod, Drift/SQLite, Dio, GoRouter, and a WebView-based chat renderer.

Prerequisites, setup, build commands, codegen, tests, and the project layout live in [`CONTRIBUTING.md`](CONTRIBUTING.md). Git, PR, CI, and release rules are in [`docs/WORKFLOW.md`](docs/WORKFLOW.md).

## 🙏 Credits

- [SillyImages](https://github.com/0xl0cal/sillyimages) — reference for the inline image generation implementation and its providers.
- [SillyTavern-CharacterLibrary](https://github.com/Sillyanonymous/SillyTavern-CharacterLibrary) — reference for JanitorAI extraction through a browser.
- [Marinara Engine](https://github.com/Pasta-Devs/Marinara-Engine) — inspiration for the agentic workflow.
- [Lumiverse](https://github.com/prolix-oc/Lumiverse) — inspiration for the agentic workflow.

### 🧪 Testers

The people who find the bugs before the release does — the app's own Hall of Fame
(**Menu → About Glaze → Hall of Fame**):

**nightsyr** *(honorary tester)*, Саша Белый, múrx, lina, ShikiN, N K, Сатаник1155.

## 📜 License

This project is licensed under the [GNU Affero General Public License v3.0](LICENSE).
