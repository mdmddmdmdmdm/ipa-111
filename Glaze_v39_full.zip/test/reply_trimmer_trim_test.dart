import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/reply_trimmer.dart';

void main() {
  _moreTrimTests();
  group('ReplyTrimmer.trimIncompleteSentences', () {
    String trim(String s) => ReplyTrimmer.trimIncompleteSentences(s);

    test('drops an unfinished sentence after an open quote', () {
      expect(trim('She smiled. "Hello there, how are'), 'She smiled.');
    });

    test('keeps whole *action* and "dialogue" spans', () {
      expect(
        trim('*She walks over.* "Hi." *She sits and'),
        '*She walks over.* "Hi."',
      );
    });

    test('abbreviations and initials are not sentence ends', () {
      expect(
        trim('Dr. Smith nodded. He turned to J. Smith and'),
        'Dr. Smith nodded.',
      );
    });

    test('a quote with a dialogue tag stays in one piece', () {
      expect(
        trim('"Where are you?" she asked. Then she'),
        '"Where are you?" she asked.',
      );
    });

    test('text that already ends cleanly is unchanged', () {
      expect(trim('Fine.'), 'Fine.');
      expect(trim('*He grins.*'), '*He grins.*');
    });

    test('text with no sentence end is unchanged', () {
      expect(trim('She smiled and then she'), 'She smiled and then she');
    });
  });
}

void _moreTrimTests() {
  group('ReplyTrimmer.trimIncompleteSentences keeps finished writing', () {
    String trim(String s) => ReplyTrimmer.trimIncompleteSentences(s);

    test('a last *action* line without a full stop is untouched', () {
      const t = 'She nods slowly.\n\n*She laughs softly*';
      expect(trim(t), t);
    });

    test('a last quoted line without a full stop is untouched', () {
      const t = 'He sighed.\n\n"I suppose you are right"';
      expect(trim(t), t);
    });

    test('an interrupted line ending in an em dash is untouched', () {
      const t = 'He said, "I just\u2014';
      expect(trim(t), t);
    });

    test('earlier paragraphs are never cut', () {
      const t =
          'First paragraph is complete. It has two sentences.\n\n'
          'Second one is fine too.\n\nThe third got cut off while the';
      expect(
        trim(t),
        'First paragraph is complete. It has two sentences.\n\n'
        'Second one is fine too.',
      );
    });

    test('a long unterminated run is left alone', () {
      final t = 'A' * 400;
      expect(trim(t), t);
    });
  });
}
