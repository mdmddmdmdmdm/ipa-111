import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';
import 'package:glaze_flutter/core/llm/reasoning_notice.dart';
import 'package:glaze_flutter/core/llm/reasoning_salvage.dart';
import 'package:glaze_flutter/core/llm/stream_accumulator.dart';

void main() {
  thinkFirstPlanTests();
  sourceLabelTests();
  group('stray <think> blocks are found before the tags are cleaned', () {
    test('a closed block is moved to the reasoning', () {
      final r = extractStrayThink('<think>She is scared.</think>"Hello."');
      expect(r.reasoning, 'She is scared.');
      expect(r.text, '"Hello."');
    });

    test('once the tags are deleted there is nothing left to find', () {
      // This is what the old order did: strip the tags, then look for them.
      final stripped = '<think>She is scared.</think>"Hello."'
          .replaceAll('<think>', '')
          .replaceAll('</think>', '');
      expect(extractStrayThink(stripped).reasoning, isNull);
    });

    test('a closing tag alone still splits thought from reply', () {
      final r = extractStrayThink('She is scared.</think>"Hello."');
      expect(r.reasoning, 'She is scared.');
      expect(r.text, '"Hello."');
    });
  });

  group('preset tags with template newlines', () {
    test('trimmed tags match the model\'s own tag', () {
      final a = StreamAccumulator(
        tagStart: '<think>',
        tagEnd: '</think>',
        hasInlineTags: true,
      );
      a.consumeDelta('<think>plan the beat</think>\n\nThe reply.');
      expect(a.reasoning, 'plan the beat');
      expect(a.text, 'The reply.');
    });
  });

  group('reasoning check note', () {
    test('is recognised and kept out of prompt history', () {
      final note = reasoningMissingNote(
        thinkFirstSent: true,
        thinkFirstOn: true,
        nativeAsked: false,
        nativeRefused: false,
        nativeHidden: false,
      );
      expect(isReasoningCheckNote(note), isTrue);
      expect(historyReasoning(note), isNull);
      expect(historyReasoning('real thinking'), 'real thinking');
      expect(historyReasoning(null), isNull);
    });

    test('explains each way reasoning can go missing', () {
      final refused = reasoningMissingNote(
        thinkFirstSent: false,
        thinkFirstOn: false,
        nativeAsked: true,
        nativeRefused: true,
        nativeHidden: false,
      );
      expect(refused, contains('refused native reasoning'));
      expect(refused, contains('Think First is off'));

      final ignored = reasoningMissingNote(
        thinkFirstSent: true,
        thinkFirstOn: true,
        nativeAsked: false,
        nativeRefused: false,
        nativeHidden: false,
      );
      expect(ignored, contains('ignored the instruction'));

      final hidden = reasoningMissingNote(
        thinkFirstSent: false,
        thinkFirstOn: true,
        nativeAsked: true,
        nativeRefused: false,
        nativeHidden: true,
      );
      expect(hidden, contains('Show Native Reasoning is off'));
    });

    test('waiting note is also a check note', () {
      final w = reasoningWaitingNote(thinkFirstSent: true, nativeAsked: true);
      expect(isReasoningCheckNote(w), isTrue);
      expect(w, contains('Think First'));
      expect(w, contains('native reasoning'));
    });
  });
}

// Think First planning step prompts.
void thinkFirstPlanTests() {
  group('Think First planning step', () {
    test('asks for plain notes, not a reply, at the chosen depth', () {
      final low = PromptHelpers.planningInstruction('low');
      final max = PromptHelpers.planningInstruction('max');
      expect(low, contains('Do NOT write the reply yet'));
      expect(low, contains('about 50 words'));
      expect(max, contains('600-900 words'));
      expect(low, isNot(contains('Always finish with the closing')));
    });

    test('the plan is handed to the reply step and kept secret', () {
      final t = PromptHelpers.planInjection('  She hides the letter.  ');
      expect(t, contains('She hides the letter.'));
      expect(t, contains('never mention the plan'));
    });

    test('planning gets its own token cap that grows with effort', () {
      expect(
        PromptHelpers.planMaxTokens('max'),
        greaterThan(PromptHelpers.planMaxTokens('min')),
      );
    });

    test('the missing note says when the planning step failed', () {
      final note = reasoningMissingNote(
        thinkFirstSent: true,
        thinkFirstOn: true,
        nativeAsked: false,
        nativeRefused: false,
        nativeHidden: false,
        planFailed: true,
      );
      expect(note, contains('planning step returned nothing'));
    });
  });
}

void sourceLabelTests() {
  group('app-made reasoning is labelled and kept out of history', () {
    test('a plan is labelled as not native', () {
      final shown = labelPlan('She hides it.', nativeFailed: false);
      expect(shown, startsWith(kReasoningSourceMarker));
      expect(shown, contains('not native reasoning'));
      expect(shown, endsWith('She hides it.'));
    });

    test('the label says native failed when it did', () {
      final shown = labelPlan('x', nativeFailed: true);
      expect(shown, contains('Native reasoning is NOT in use'));
    });

    test('history gets the plan without its label', () {
      final shown = labelPlan('She hides it.', nativeFailed: true);
      expect(stripReasoningLabel(shown), 'She hides it.');
      expect(historyReasoning(shown), 'She hides it.');
      expect(historyReasoning('plain thinking'), 'plain thinking');
      expect(historyReasoning(labelPlan('', nativeFailed: false)), isNull);
    });

    test('a labelled plan followed by the model\'s own reasoning', () {
      final merged =
          '${labelPlan('plan', nativeFailed: false)}\n\n---\n\nmodel thought';
      expect(stripReasoningLabel(merged), 'plan\n\n---\n\nmodel thought');
    });

    test('the failure error names the model and never claims native', () {
      final off = nativeFailureMessage(
        model: 'mag-mell',
        inline: false,
        thinkFirstOn: false,
      );
      expect(off, contains('mag-mell'));
      expect(off, contains('No reasoning is being forced'));
      expect(off, contains('Think First (not native)'));

      final on = nativeFailureMessage(
        model: 'mag-mell',
        inline: false,
        thinkFirstOn: true,
      );
      expect(on, contains('Think First (not native) is on'));
      expect(on, isNot(contains('No reasoning is being forced')));

      final inline = nativeFailureMessage(
        model: 'mag-mell',
        inline: true,
        thinkFirstOn: false,
      );
      expect(inline, contains('<think> tags'));
      expect(inline, contains('not native'));
    });

    test('reasoning from the model\'s own tags is labelled not native', () {
      final shown = labelInline('She is shy.');
      expect(shown, startsWith(kReasoningSourceMarker));
      expect(shown, contains('not native reasoning'));
      expect(historyReasoning(shown), 'She is shy.');
    });
  });
}
