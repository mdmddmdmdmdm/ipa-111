import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/model_context_limit.dart';
import 'package:glaze_flutter/core/llm/model_probe.dart';

void main() {
  group('ModelContextLimitService.fromProbe', () {
    test('the model maximum is the limit', () {
      final info = ModelContextLimitService.fromProbe(
        const ModelProbeResult(
          maxContext: 131072,
          loadedContext: 8192,
          sources: ['Ollama /api/show'],
        ),
      );
      expect(info.isKnown, isTrue);
      expect(info.limit, 131072);
      expect(info.loaded, 8192);
      expect(info.source, 'Ollama /api/show');
      expect(info.estimate, isFalse);
    });

    test('only a loaded size still gives a limit', () {
      final info = ModelContextLimitService.fromProbe(
        const ModelProbeResult(loadedContext: 4096),
      );
      expect(info.limit, 4096);
      expect(info.loaded, isNull);
    });

    test('the built-in table is flagged as an estimate', () {
      final info = ModelContextLimitService.fromProbe(
        const ModelProbeResult(
          maxContext: 128000,
          sources: ['Built-in table (estimate)'],
        ),
      );
      expect(info.limit, 128000);
      expect(info.estimate, isTrue);
    });

    test('nothing reported is unknown, never a guess', () {
      final info = ModelContextLimitService.fromProbe(
        const ModelProbeResult(notes: ['not reported']),
      );
      expect(info.status, ContextLimitStatus.unknown);
      expect(info.limit, isNull);
    });
  });
}
