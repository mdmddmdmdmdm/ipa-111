import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/converters/reasoning_effort.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';
import 'package:glaze_flutter/core/llm/transport/chat_transport_request.dart';
import 'package:glaze_flutter/core/llm/transport/ollama_chat_transport.dart';
import 'package:glaze_flutter/features/settings/api_list_provider.dart';

void main() {
  group('endpoint drop-down', () {
    test('offers the new server first and keeps the old one second', () {
      expect(kApiServerChoices.length, 2);
      expect(kApiServerChoices.first.endpoint, kDefaultApiPresetEndpoint);
      expect(kDefaultApiPresetEndpoint, 'http://192.168.1.254:11434/v1');
      expect(kApiServerChoices.last.endpoint, kSecondApiPresetEndpoint);
      expect(kSecondApiPresetEndpoint, 'http://192.168.1.59:11434/v1');
    });

    test('a server is recognised however its address is typed', () {
      expect(
        apiServerChoiceFor('http://192.168.1.254:11434/v1/chat/completions'),
        kApiServerChoices.first,
      );
      expect(
        apiServerChoiceFor('192.168.1.254:11434'),
        kApiServerChoices.first,
      );
      expect(
        apiServerChoiceFor('HTTP://192.168.1.59:11434/v1'),
        kApiServerChoices.last,
      );
      expect(apiServerChoiceFor('https://api.openai.com/v1'), isNull);
      expect(apiServerChoiceFor(''), isNull);
    });

    test('host:port is read without the scheme or path', () {
      expect(apiServerKey('http://192.168.1.254:11434/v1'), '192.168.1.254:11434');
      expect(apiServerKey('localhost:11434/v1'), 'localhost:11434');
    });

    test('built-in presets start at the top reasoning effort', () {
      expect(kDefaultApiPresetReasoningEffort, 'max');
    });
  });

  group('reasoning depth (V67)', () {
    test('the steps still grow with the level', () {
      int words(String e) => PromptHelpers.thinkFirstWords(e).max;
      expect(words('low') < words('medium'), isTrue);
      expect(words('medium') < words('high'), isTrue);
      expect(words('high') < words('max'), isTrue);
      expect(nativeThinkingWordLimit('medium') < nativeThinkingWordLimit('high'),
          isTrue);
    });

    test('native limits stay inside their Think First range', () {
      for (final e in ['min', 'low', 'medium', 'high']) {
        expect(
          nativeThinkingWordLimit(e),
          greaterThanOrEqualTo(PromptHelpers.thinkFirstWords(e).max - 10),
          reason: e,
        );
      }
    });

    test('Think First text carries no unexpanded macros', () {
      for (final e in ['min', 'low', 'medium', 'high', 'max']) {
        expect(PromptHelpers.thinkFirstFor(e), isNot(contains('{{')));
        expect(PromptHelpers.planningInstruction(e), isNot(contains('{{')));
      }
    });

    test('token room covers the longest notes at each level', () {
      for (final e in ['medium', 'high', 'max']) {
        // About 1.4 tokens a word, plus room for the reply to start.
        final needed = (PromptHelpers.thinkFirstWords(e).max * 1.4).round();
        expect(PromptHelpers.thinkFirstExtraTokens(e), greaterThan(needed),
            reason: e);
      }
    });

    test('the planning step runs at a calmer temperature', () {
      expect(PromptHelpers.planTemperature, lessThanOrEqualTo(0.6));
    });
  });

  group('reasoning length (V67)', () {
    const ep = 'http://192.168.1.254:11434/v1';
    ChatTransportRequest native(String effort, {String model = 'gemma-x'}) =>
        ChatTransportRequest(
          endpoint: ep,
          apiKey: '',
          model: model,
          messages: const [
            {'role': 'system', 'content': 'rules'},
            {'role': 'user', 'content': 'hi'},
          ],
          maxTokens: 350,
          temperature: 1.0,
          topP: 0.95,
          requestReasoning: true,
          reasoningEffort: effort,
          thinkWordLimit: nativeThinkingWordLimit(effort),
          thinkWordMin: nativeThinkingWordMin(effort),
        );

    test('Think First and native use one range per step', () {
      for (final e in ['min', 'low', 'medium', 'high', 'max']) {
        final r = PromptHelpers.thinkFirstWords(e);
        expect(r.min, nativeThinkingWordMin(e), reason: e);
        expect(r.max, nativeThinkingWordLimit(e), reason: e);
        expect(r.min < r.max, isTrue, reason: e);
      }
    });

    test('Auto has no range on either path', () {
      expect(PromptHelpers.hasFixedLength('auto'), isFalse);
      expect(nativeThinkingWordLimit('auto'), 0);
      expect(nativeThinkingWordMin('auto'), 0);
      expect(nativeThinkingWordLimit(null), 0);
      final long = List.filled(5000, 'word').join(' ');
      expect(PromptHelpers.clampPlan(long, 'auto'), long);
      expect(PromptHelpers.planTooShort('one line', 'auto'), isFalse);
    });

    test('Think First notes are cut at the top of the range', () {
      final long = List.filled(2000, 'word.').join(' ');
      for (final e in ['medium', 'high', 'max']) {
        final cut = PromptHelpers.clampPlan(long, e);
        final n = RegExp(r'\S+').allMatches(cut).length;
        expect(n, lessThanOrEqualTo(PromptHelpers.thinkFirstWords(e).max));
        expect(n, greaterThan(PromptHelpers.thinkFirstWords(e).max * 0.9));
      }
      final inside = List.filled(200, 'word').join(' ');
      expect(PromptHelpers.clampPlan(inside, 'medium'), inside);
    });

    test('a cut lands on a full sentence when that keeps most of the notes', () {
      final text = '${List.filled(250, 'word').join(' ')}. And then some more '
          'words that run past the limit and keep going for a while longer '
          'than the medium range allows at all, truly.';
      final cut = PromptHelpers.clampPlan(
        '$text ${List.filled(200, 'extra').join(' ')}',
        'medium',
      );
      expect(cut.endsWith('.'), isTrue);
    });

    test('notes under the bottom of the range are asked to continue', () {
      final under = List.filled(149, 'w').join(' ');
      final at = List.filled(150, 'w').join(' ');
      expect(PromptHelpers.planTooShort(under, 'medium'), isTrue);
      expect(PromptHelpers.planTooShort(at, 'medium'), isFalse);
    });

    test('the planning token stop sits just above the top of the range', () {
      for (final e in ['medium', 'high', 'max']) {
        final max = PromptHelpers.thinkFirstWords(e).max;
        final t = PromptHelpers.planMaxTokens(e);
        expect(t, greaterThan((max * 1.4).round()), reason: e);
        expect(t, lessThan((max * 2.0).round()), reason: e);
      }
      expect(PromptHelpers.planMaxTokens('auto'),
          greaterThanOrEqualTo(PromptHelpers.planMaxTokens('max')));
    });

    test('native thinking on a step carries its range, Auto carries none', () {
      final high = OllamaChatTransport.buildBody(native('high'));
      final last = (high['messages'] as List).last as Map;
      expect(last['content'], startsWith('hi'));
      expect(last['content'], contains('about 400-650 words'));

      final auto = OllamaChatTransport.buildBody(native('auto'));
      expect(
        ((auto['messages'] as List).last as Map)['content'],
        'hi',
      );
    });

    test('answer-now drops the length note', () {
      final body = OllamaChatTransport.buildBody(native('medium'));
      final out = OllamaChatTransport.answerNowBody(body, 'thoughts');
      final text = ((out['messages'] as List).last as Map)['content'] as String;
      expect(text, isNot(contains('Reasoning length')));
      expect(text, contains('thoughts'));
    });
  });
}
