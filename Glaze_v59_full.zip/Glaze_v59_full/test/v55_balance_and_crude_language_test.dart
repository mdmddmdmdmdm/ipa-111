import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';

void main() {
  group('description / dialogue balance is measurable and wins', () {
    String text(PromptDialogueBalance b, {PromptResponseLength? len}) =>
        PromptHelpers(
          dialogueBalance: b,
          length: len ?? PromptResponseLength.none,
        ).buildText()!;

    test('every level gives a sentence ratio and a final count check', () {
      final ratios = {
        PromptDialogueBalance.mostlyDescription: 'four sentences of description',
        PromptDialogueBalance.moreDescription: 'two sentences of description',
        PromptDialogueBalance.balanced: 'one sentence of description',
        PromptDialogueBalance.moreDialogue: 'two sentences a character speaks',
        PromptDialogueBalance.mostlyDialogue: 'four sentences a character speaks',
      };
      ratios.forEach((b, ratio) {
        expect(text(b), contains(ratio), reason: b.name);
        expect(text(b), contains('count your sentences'), reason: b.name);
        expect(text(b), contains('Dialogue means the words a character says'),
            reason: b.name);
      });
    });

    test('it overrides the style of earlier replies', () {
      for (final b in PromptDialogueBalance.values) {
        if (b == PromptDialogueBalance.none) continue;
        expect(text(b), contains('even if the earlier replies'), reason: b.name);
      }
    });

    test('it is the last instruction in the block', () {
      final t = PromptHelpers(
        dialogueBalance: PromptDialogueBalance.mostlyDialogue,
        length: PromptResponseLength.medium,
        endOnQuestion: true,
        emojis: true,
      ).buildText()!;
      expect(t.lastIndexOf('DIALOGUE BALANCE'),
          greaterThan(t.lastIndexOf('LENGTH (strict rule)')));
      expect(t.lastIndexOf('DIALOGUE BALANCE'),
          greaterThan(t.lastIndexOf('ENDING ON A QUESTION')));
    });

    test('a dialogue-leaning balance drops "several sentences of narration"', () {
      final withDialogue = text(
        PromptDialogueBalance.mostlyDialogue,
        len: PromptResponseLength.medium,
      );
      expect(withDialogue, contains('3 to 4 paragraphs'));
      expect(withDialogue, isNot(contains('not a single short line')));
      expect(withDialogue, contains('a paragraph can be a character speaking'));
      final withDescription = text(
        PromptDialogueBalance.mostlyDescription,
        len: PromptResponseLength.medium,
      );
      expect(withDescription, contains('not a single short line'));
      expect(
        PromptHelpers(length: PromptResponseLength.medium).buildText(),
        contains('not a single short line'),
      );
    });

    test('the paragraph count is unchanged by the balance', () {
      for (final len in PromptResponseLength.values) {
        if (len == PromptResponseLength.none) continue;
        final plain = PromptHelpers(length: len).lengthText;
        final dlg = PromptHelpers(
          length: len,
          dialogueBalance: PromptDialogueBalance.mostlyDialogue,
        ).lengthText;
        expect(dlg.split('.').first, plain.split('.').first, reason: len.name);
      }
    });
  });

  group('crude language helper', () {
    test('off adds nothing; on adds the rule', () {
      expect(const PromptHelpers().buildText(), isNull);
      final t = const PromptHelpers(crudeLanguage: true).buildText()!;
      expect(t, contains('CRUDE LANGUAGE'));
      expect(t, contains('ass, not "butt"'));
      expect(t, contains('never slurs'));
    });

    test('is saved, counted and copied', () {
      const h = PromptHelpers(crudeLanguage: true);
      expect(PromptHelpers.fromJson(h.toJson()).crudeLanguage, isTrue);
      expect(PromptHelpers.fromJson({'formatting': true}).crudeLanguage, isFalse);
      expect(h.activeCount, 1);
      expect(h.anyActive, isTrue);
      expect(const PromptHelpers().copyWith(crudeLanguage: true).crudeLanguage,
          isTrue);
    });

    test('stays on when the app writes the user\'s message', () {
      const h = PromptHelpers(crudeLanguage: true, userAgency: true);
      expect(h.forImpersonation().buildText(), contains('CRUDE LANGUAGE'));
    });
  });
}
