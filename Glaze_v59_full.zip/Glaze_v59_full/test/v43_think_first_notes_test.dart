import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';

void main() {
  group('Think First writes notes, not the reply', () {
    test('every level forbids writing the reply and asks for analysis', () {
      for (final e in ['min', 'low', 'medium', 'high', 'max']) {
        final plan = PromptHelpers.planningInstruction(e);
        expect(plan, contains('never the reply'), reason: e);
        expect(plan, contains('no dialogue in quotes'), reason: e);
        final inline = PromptHelpers.thinkFirstFor(e);
        expect(inline, contains('never the reply'), reason: e);
      }
    });

    test('no level asks for a draft of the reply', () {
      final max = PromptHelpers.thinkFirstFor('max');
      expect(max, isNot(contains('draft it')));
      expect(max, contains('Rules check'));
    });

    test('the strict retry says the last attempt was the reply', () {
      final t = PromptHelpers.planningInstruction('medium', strict: true);
      expect(t, contains('YOUR LAST ATTEMPT WAS THE REPLY ITSELF'));
      expect(PromptHelpers.planningInstruction('medium'), isNot(contains('LAST ATTEMPT')));
    });

    test('a plan that is the reply itself is recognised', () {
      const reply =
          '[Date: 10/22/2023 | Time: 22:47]\n[Location: Claire\'s Apartment]\n\n'
          '*Claire stared at the phone.* "That was weird."';
      expect(PromptHelpers.planLooksLikeReply(reply), isTrue);
      const noQuotesLines =
          '*She hesitated.* "Maybe," she whispered, *looking at the floor.*';
      expect(PromptHelpers.planLooksLikeReply(noQuotesLines), isTrue);
    });

    test('real notes are not mistaken for a reply', () {
      const notes =
          'Situation: Claire just got a message and is rattled.\n'
          'Characters: Claire wants to hide it; she does not trust Jamal yet.\n'
          'Next beat: she asks Jamal where he was, but does not mention the '
          'message.';
      expect(PromptHelpers.planLooksLikeReply(notes), isFalse);
      const withQuote =
          'Situation: Jamal said "I was at work" earlier.\n'
          'Next beat: Claire questions that.';
      expect(PromptHelpers.planLooksLikeReply(withQuote), isFalse);
    });
  });
}
