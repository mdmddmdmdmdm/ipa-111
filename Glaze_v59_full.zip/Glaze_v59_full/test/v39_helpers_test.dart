import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';
import 'package:glaze_flutter/core/llm/reply_trimmer.dart';

void main() {
  group('response lengths', () {
    test('each length asks for its paragraph range', () {
      String text(PromptResponseLength l) =>
          PromptHelpers(length: l).buildText()!;
      expect(text(PromptResponseLength.tiny), contains('exactly ONE paragraph'));
      expect(text(PromptResponseLength.short), contains('1 to 2 paragraphs'));
      expect(text(PromptResponseLength.medium), contains('3 to 4 paragraphs'));
      expect(text(PromptResponseLength.large), contains('5 to 6 paragraphs'));
      expect(text(PromptResponseLength.xlarge), contains('7 to 8 paragraphs'));
      expect(text(PromptResponseLength.maximum), contains('9 to 10 paragraphs'));
    });

    test('the ceiling is the top of the range', () {
      expect(PromptResponseLength.tiny.maxParagraphs, 1);
      expect(PromptResponseLength.short.maxParagraphs, 2);
      expect(PromptResponseLength.medium.maxParagraphs, 4);
      expect(PromptResponseLength.large.maxParagraphs, 6);
      expect(PromptResponseLength.xlarge.maxParagraphs, 8);
      expect(PromptResponseLength.maximum.maxParagraphs, 10);
    });

    test('a saved "long" is now Large; round trip keeps the rest', () {
      expect(PromptResponseLength.fromName('long'), PromptResponseLength.large);
      final back = PromptHelpers.fromJson(
        const PromptHelpers(length: PromptResponseLength.xlarge).toJson(),
      );
      expect(back.length, PromptResponseLength.xlarge);
    });
  });

  group('description / dialogue balance', () {
    test('off adds nothing; each option states its ratio', () {
      expect(const PromptHelpers().buildText(), isNull);
      String text(PromptDialogueBalance b) =>
          PromptHelpers(dialogueBalance: b).buildText()!;
      expect(text(PromptDialogueBalance.mostlyDescription), contains('80% description'));
      expect(text(PromptDialogueBalance.moreDescription), contains('65% description'));
      expect(text(PromptDialogueBalance.balanced), contains('half description and half'));
      expect(text(PromptDialogueBalance.moreDialogue), contains('65% dialogue'));
      expect(text(PromptDialogueBalance.mostlyDialogue), contains('80% dialogue'));
    });

    test('is saved and counted', () {
      const h = PromptHelpers(
        dialogueBalance: PromptDialogueBalance.moreDialogue,
        endOnQuestion: true,
      );
      final back = PromptHelpers.fromJson(h.toJson());
      expect(back.dialogueBalance, PromptDialogueBalance.moreDialogue);
      expect(back.endOnQuestion, isTrue);
      expect(h.activeCount, 2);
      expect(h.anyActive, isTrue);
    });
  });

  group('end on a question', () {
    test('the question is the last thing said; narration is kept short', () {
      const t =
          '*She crosses her arms.* "Where were you last night? I waited for '
          'hours. Say something."\n\n*She taps her foot.*\n\n"Well?"';
      expect(
        ReplyTrimmer.endOnQuestion(t),
        '*She crosses her arms.* "Where were you last night?"\n\n'
        '*She taps her foot.*',
      );
    });

    test('a run of questions stays together, later dialogue goes', () {
      const t =
          '*She smiles.* "How was your day? Did you eat?" *She waits.* '
          '"I missed you so much."';
      expect(
        ReplyTrimmer.endOnQuestion(t),
        '*She smiles.* "How was your day? Did you eat?" *She waits.*',
      );
    });

    test('a question that already ends things, or no question, is unchanged', () {
      const a = '"I made dinner. Do you want some?" *She sets a plate down.*';
      const b = '"No questions here." *She nods.*';
      expect(ReplyTrimmer.endOnQuestion(a), a);
      expect(ReplyTrimmer.endOnQuestion(b), b);
    });
  });

  group('user agency', () {
    test('second person in the middle of a sentence is cut', () {
      expect(
        ReplyTrimmer.enforceUserAgency(
          '*Mia pours tea.* *She smiles as you step closer.*',
          'Sam',
        ),
        '*Mia pours tea.*',
      );
      expect(
        ReplyTrimmer.enforceUserAgency(
          '*Mia watches as you nod slowly.* "Good."',
          'Sam',
        ),
        '"Good."',
      );
    });

    test('the user\'s words tagged "you say" are cut', () {
      expect(
        ReplyTrimmer.enforceUserAgency(
          '"I\'m here," you say softly. *Mia smiles.*',
          'Sam',
        ),
        '*Mia smiles.*',
      );
    });

    test('a line of the character talking to the user is kept', () {
      const ok = '*Mia smiles.* "If you nod, I will go."';
      expect(ReplyTrimmer.enforceUserAgency(ok, 'Sam'), ok);
    });

    test('a reply being written is cut only when text comes before', () {
      expect(
        ReplyTrimmer.userViolationCutInProgress(
          '*Mia pours tea.* *You nod.*',
          'Sam',
        ),
        isNotNull,
      );
      expect(
        ReplyTrimmer.userViolationCutInProgress('*You nod.*', 'Sam'),
        isNull,
      );
    });
  });
}
