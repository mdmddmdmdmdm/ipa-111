import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/transport/ollama_chat_transport.dart';

Map<String, dynamic> _load(String file) =>
    jsonDecode(File('assets/presets/$file.json').readAsStringSync())
        as Map<String, dynamic>;

List<Map<String, dynamic>> _prompts(String file) => [
  for (final p in (_load(file)['prompts'] as List))
    Map<String, dynamic>.from(p as Map),
];

void main() {
  const withBlock = [
    'mine',
    'be_yourself',
    'balanced_roleplay',
    'shin_pers_notime',
  ];
  const withoutBlock = ['no_prompt', 'shino_personal_combined', 'shino'];

  group('User Agency block in the four presets', () {
    for (final f in withBlock) {
      test('$f has one enabled User Agency block before Chat History', () {
        final prompts = _prompts(f);
        final hits = prompts.where((p) => p['name'] == 'User Agency').toList();
        expect(hits.length, 1);
        final block = hits.single;
        expect(block['enabled'], true);
        expect(block['role'], 'system');
        final content = block['content'] as String;
        expect(content, contains('{{user}}'));
        expect(content, contains('Never write for {{user}}'));
        expect(content, contains('impersonation'));
        final at = prompts.indexWhere((p) => p['name'] == 'User Agency');
        final history = prompts.indexWhere((p) => p['name'] == 'Chat History');
        expect(at, lessThan(history));
      });
    }

    test('the other bundled presets are not given the block', () {
      for (final f in withoutBlock) {
        final file = File('assets/presets/$f.json');
        if (!file.existsSync()) continue;
        expect(
          _prompts(f).where((p) => p['name'] == 'User Agency'),
          isEmpty,
          reason: f,
        );
      }
    });
  });

  group('answer-now request after the thinking limit', () {
    test('tells the model not to start reasoning again', () {
      final body = <String, dynamic>{
        'model': 'm',
        'messages': [
          {'role': 'user', 'content': 'hi'},
        ],
        'think': true,
      };
      final out = OllamaChatTransport.answerNowBody(body, 'thought so far');
      final last = (out['messages'] as List).last as Map;
      expect(out['think'], false);
      expect(last['content'], contains('thought so far'));
      expect(last['content'], contains('do not start reasoning again'));
    });
  });
}
