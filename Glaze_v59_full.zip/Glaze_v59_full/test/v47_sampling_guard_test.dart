import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/transport/chat_transport_request.dart';
import 'package:glaze_flutter/core/llm/transport/extra_request_parameters.dart';
import 'package:glaze_flutter/core/llm/transport/llm_protocol.dart';
import 'package:glaze_flutter/core/llm/transport/openai_chat_transport.dart';
import 'package:glaze_flutter/core/models/api_config.dart';
import 'package:glaze_flutter/core/models/extra_request_parameter.dart';
import 'package:glaze_flutter/core/services/featured_presets.dart';
import 'package:glaze_flutter/features/settings/api_config_draft.dart';

const _both = [
  ExtraRequestParameter(key: 'min_p', value: '0.05'),
  ExtraRequestParameter(key: 'smoothing_factor', value: '0.3'),
  ExtraRequestParameter(key: 'seed', value: '7'),
];

ApiConfig cfg(String protocol) => ApiConfig(
  id: 'x',
  protocol: protocol,
  model: 'm',
  endpoint: 'https://example.com',
  omitTemperature: false,
  omitTopP: false,
  extraRequestParameters: _both,
);

Map<String, bool> enabledByKey(List<ExtraRequestParameter> l) => {
  for (final p in l) p.key: p.enabled,
};

void main() {
  test('Min P and Smoothing Factor are switched off where unsupported', () {
    for (final proto in [
      LlmProtocol.openai,
      LlmProtocol.openaiResponses,
      LlmProtocol.anthropic,
      LlmProtocol.gemini,
    ]) {
      final e = enabledByKey(
        disableUnsupportedSamplingExtras(proto, _both),
      );
      expect(e['min_p'], isFalse, reason: proto);
      expect(e['smoothing_factor'], isFalse, reason: proto);
      expect(e['seed'], isTrue, reason: proto);
    }
  });

  test('OpenRouter keeps Min P but not Smoothing Factor', () {
    final e = enabledByKey(
      disableUnsupportedSamplingExtras(LlmProtocol.openrouter, _both),
    );
    expect(e['min_p'], isTrue);
    expect(e['smoothing_factor'], isFalse);
  });

  test('custom endpoints keep both, list returned untouched', () {
    expect(
      identical(
        disableUnsupportedSamplingExtras(LlmProtocol.customChatCompletion, _both),
        _both,
      ),
      isTrue,
    );
  });

  test('the value survives the switch-off', () {
    final out = disableUnsupportedSamplingExtras(LlmProtocol.gemini, _both);
    expect(out.firstWhere((p) => p.key == 'min_p').value, '0.05');
  });

  test('saving a preset on Gemini disables the hidden entries', () {
    final n = ApiConfigDraft.normalizeValues(cfg(LlmProtocol.gemini));
    expect(enabledByKey(n.extraRequestParameters)['min_p'], isFalse);
  });

  test('request built from an unsupported protocol does not carry them', () {
    final r = ChatTransportRequest.fromApiConfig(
      cfg(LlmProtocol.openai),
      messages: const [
        {'role': 'user', 'content': 'hi'},
      ],
    );
    final body = OpenAiChatTransport.buildBody(r, protocol: LlmProtocol.openai);
    expect(body.containsKey('min_p'), isFalse);
    expect(body.containsKey('smoothing_factor'), isFalse);
    expect(body['seed'], 7);
  });

  test('custom endpoint request still sends both', () {
    final r = ChatTransportRequest.fromApiConfig(
      cfg(LlmProtocol.customChatCompletion),
      messages: const [
        {'role': 'user', 'content': 'hi'},
      ],
    );
    final body = OpenAiChatTransport.buildBody(
      r,
      protocol: LlmProtocol.customChatCompletion,
    );
    expect(body['min_p'], 0.05);
    expect(body['smoothing_factor'], 0.3);
  });

  test('Shin-Pers-Notime is a bundled preset and its asset is valid', () {
    final b = bundledPresets.firstWhere(
      (p) => p.id == 'bundled_shin_pers_notime',
    );
    expect(b.name, 'Shin-Pers-Notime');
    final json =
        jsonDecode(File(b.jsonAsset).readAsStringSync()) as Map<String, dynamic>;
    expect(json['name'], 'Shin-Pers-Notime');
    expect((json['prompts'] as List).length, 26);
    final ids = bundledPresets.map((p) => p.id).toSet();
    expect(ids.length, bundledPresets.length);
    final order = bundledPresets.map((p) => p.createdAt).toSet();
    expect(order.length, bundledPresets.length);
  });
}
