import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/prompt_helpers.dart';

void main() {
  group('Think First depth follows the reasoning effort', () {
    test('each level is its own checklist, not just a bigger number', () {
      expect(PromptHelpers.thinkFirstFor('medium'), contains('3 labeled parts'));
      expect(PromptHelpers.thinkFirstFor('high'), contains('4 labeled parts'));
      expect(PromptHelpers.thinkFirstFor('max'), contains('6 labeled parts'));
      expect(PromptHelpers.thinkFirstFor('max'), contains('Do not stop before Rules check'));
    });

    test('word ranges grow with the level and Auto is Medium', () {
      int min(String e) => PromptHelpers.thinkFirstWords(e).min;
      int max(String e) => PromptHelpers.thinkFirstWords(e).max;
      expect(min('low') < min('medium'), isTrue);
      expect(min('medium') < min('high'), isTrue);
      expect(min('high') < min('max'), isTrue);
      expect(max('max'), 900);
      expect(PromptHelpers.thinkFirstWords('auto'), PromptHelpers.thinkFirstWords('medium'));
    });

    test('notes far too short for the level are asked to continue', () {
      final short = List.filled(30, 'word').join(' ');
      expect(PromptHelpers.planTooShort(short, 'max'), isTrue);
      expect(PromptHelpers.planTooShort(short, 'high'), isTrue);
      expect(PromptHelpers.planTooShort(short, 'min'), isFalse);
      expect(PromptHelpers.planTooShort(short, 'low'), isFalse);
      final enough = List.filled(400, 'word').join(' ');
      expect(PromptHelpers.planTooShort(enough, 'max'), isFalse);
    });

    test('the continuation carries the notes so far and the same depth', () {
      final t = PromptHelpers.planContinuation('max', 'She hides the letter.');
      expect(t, contains('She hides the letter.'));
      expect(t, contains('6 labeled parts'));
      expect(t, contains('Write only the additional notes'));
    });
  });
}
