// The message renderer, in two phases.
//
//   Phase A — parse. The message is handed to the browser's own HTML parser.
//     What is an element, how elements nest, and where an unclosed tag ends
//     are the parser's answers, not ours. That is what makes a card render as
//     a card from its first streamed chunk instead of flickering as raw tags,
//     and it is why there is no list of block tags and no "orphan" counter
//     here any more.
//
//   Phase B — format the text. Markdown is applied to text nodes, never to a
//     string with live markup in it. Attributes, `<style>`, `<script>`, `<pre>`
//     and `<code>` are out of reach by construction, and a `<p>` of ours is
//     only ever added at the top level of the message — never inside markup
//     the author wrote.
//
// Around those two: `protect.js` takes out the regions that are not markup
// (code, image tags, a `<think>` panel) before parsing, and puts them back
// afterwards. See docs/rules/message-rendering.md.

import { expandMacros } from './macros.js';
import { escapeProseTags, styledElementNames } from './html_scan.js';
import {
  ANY_PLACEHOLDER,
  createStore,
  maskCodeElements,
  protectRegions,
} from './protect.js';
import {
  colorUnquotedText,
  convertFontElements,
  formatContainer,
  parseHtml,
  replacePlaceholders,
} from './dom_format.js';
import { renderImageBlock } from './image_blocks.js';

export {
  parseImageResultPayload,
  parseImageResultElement,
  parseImagePendingPayload,
  parseImagePendingElement,
} from './image_blocks.js';

// Both icons ship in the button; `data-copied` decides which one shows.
const COPY_ICON =
  '<svg class="code-copy-icon" viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>' +
  '<svg class="code-copied-icon" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>';

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export class Formatter {
  constructor() {
    this.cache = new Map();
    this.cacheMaxSize = 500;
    // Appearance option, off by default: text outside quotation marks takes
    // the narration colour. Set through Bridge.setUnquotedAsNarration.
    this.unquotedAsNarration = false;
  }

  setUnquotedAsNarration(enabled) {
    const next = enabled === true;
    if (next === this.unquotedAsNarration) return false;
    this.unquotedAsNarration = next;
    // Cached HTML was built under the old setting.
    this.cache.clear();
    return true;
  }

  // [inReasoning] formats a body that *is* a reasoning block — the split-out
  // `message.reasoning`, which the renderer shows in its own panel. Dart never
  // scans that field for image tags, so a tag in it must not render as a block
  // here either (INV-IG11); the same flag covers a `<think>` block found inline
  // in the message body.
  format(text, isUser = false, inReasoning = false, useCache = true) {
    const key = `${text}:${isUser}:${inReasoning}:${this.unquotedAsNarration}`;
    if (useCache && this.cache.has(key)) return this.cache.get(key);

    let result;
    try {
      result = this._render(text, isUser, inReasoning);
    } catch (e) {
      console.error('Formatter error:', e);
      result = escapeHtml(text || '').replace(/\n/g, '<br>');
    }

    const leaked = result.match(ANY_PLACEHOLDER);
    if (leaked) {
      console.error('Formatter LEAK:', leaked, 'text:', text?.substring(0, 100));
      result = result.replace(ANY_PLACEHOLDER, '');
    }

    if (useCache) {
      if (this.cache.size >= this.cacheMaxSize) {
        const firstKey = this.cache.keys().next().value;
        this.cache.delete(firstKey);
      }
      this.cache.set(key, result);
    }
    return result;
  }

  _render(text, isUser, inReasoning) {
    if (!text) return '';
    const source = expandMacros(text)
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .trim();

    const regions = createStore('P');

    const staged = protectRegions(source, {
      store: regions,
      inReasoning,
      isUser,
    });
    // `<style>` and `<script>` bodies are code, and the tag scan below would
    // read them as prose: `i<n; i++) { if (i>` in a script is a tag to it, and
    // escaping that corrupts the script. They are masked for its length and
    // put back for the parser.
    const styled = styledElementNames(staged);
    const code = maskCodeElements(staged);

    // Nothing has read this string as markdown. The parse comes first, and
    // every markdown pass — style markers included — runs in phase B, on a run
    // of one container's text with its elements already masked out.
    const tree = parseHtml(code.unmask(escapeProseTags(code.masked, styled)), document);

    formatContainer(tree, { isRoot: true, allowBlocks: true });

    let imageIndex = 0;
    replacePlaceholders(tree, 'P', (index) => {
      const region = regions.get(index);
      if (!region) return null;
      if (region.kind === 'image') {
        // Document order: the blocks are numbered the way
        // ImageTagMarkup.scanImageBlocks() numbers them on the Dart side, so
        // `data-img-index` addresses one image and not the whole message.
        return Array.from(
          parseHtml(renderImageBlock(region.block, imageIndex++), document).childNodes,
        );
      }
      return Array.from(parseHtml(this._regionHtml(region, isUser), document).childNodes);
    });

    // After the placeholders are resolved on purpose: code blocks, images,
    // reasoning panels and other protected regions are real elements by now and
    // are skipped, instead of being wrapped while still a bare token. A
    // reasoning panel's own body is the model's notes, not the story, so it
    // keeps its look.
    if (this.unquotedAsNarration && !inReasoning) colorUnquotedText(tree);

    convertFontElements(tree);
    return this._serialize(tree);
  }

  _regionHtml(region, isUser) {
    switch (region.kind) {
      case 'code': {
        const langAttr = region.lang ? ` class="language-${region.lang}"` : '';
        // The header is ours, not the message's: the copy button is handled by
        // the `copy-code` action in bridge/interaction_dispatch.js.
        return '<div class="code-block-wrapper"><div class="code-block-header">' +
          `<span class="code-lang">${region.lang}</span>` +
          '<button type="button" class="code-copy-btn" data-action="copy-code" ' +
          `aria-label="Copy code">${COPY_ICON}</button></div>` +
          `<pre><code${langAttr}>${escapeHtml(region.code)}</code></pre></div>`;
      }
      case 'inline-code':
        // Escaped: a tag written inside backticks is shown, not rendered.
        return `<code>${escapeHtml(region.code)}</code>`;
      case 'think':
        return '<details class="reasoning-block">' +
          '<summary class="reasoning-summary">💭 Reasoning</summary>' +
          `<div class="reasoning-content">${this._render(region.content, isUser, true)}</div>` +
          '</details>';
      case 'html':
        return region.html;
      case 'text':
        return escapeHtml(region.text);
      default:
        return '';
    }
  }

  _serialize(tree) {
    const template = document.createElement('template');
    template.content.appendChild(tree);
    return template.innerHTML;
  }
}
