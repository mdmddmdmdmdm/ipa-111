// The document contract: what a card may rely on inside a message shadow root.
//
// One case per item of docs/INVARIANTS.md § Message document contract. A hole
// closed here is a hole closed by list, not by complaint.
import { test, expect } from '@playwright/test';
import { card } from '../corpus/cards.js';
import { openHarness, render } from './harness.js';

test.beforeEach(async ({ page }) => {
  await openHarness(page);
});

test('INV-MR1 a card script declares the function its onclick calls', async ({ page }) => {
  await render(page, card('script-card').text);
  const before = await page.evaluate(() =>
    window.harness.currentRoot().querySelector('#jsc-out').hidden);
  expect(before).toBe(true);

  await page.evaluate(() => window.harness.currentRoot().querySelector('#jsc-btn').click());
  const after = await page.evaluate(() =>
    window.harness.currentRoot().querySelector('#jsc-out').hidden);
  expect(after, 'the script runs in the global scope, so onclick resolves').toBe(false);
  expect(page.__failures).toEqual([]);
});

test('INV-MR1 a message script leaves no <script> behind', async ({ page }) => {
  await render(page, card('script-card').text);
  const shape = await page.evaluate(() => ({
    inMessage: window.harness.currentRoot().querySelectorAll('script').length,
    // The element the runner injects to reach global scope is removed again.
    inHead: document.head.querySelectorAll('script:not([src])').length,
  }));
  expect(shape.inMessage).toBe(0);
  expect(shape.inHead).toBe(0);
});

test('INV-MR3/MR4 document lookups find the message\'s own elements', async ({ page }) => {
  await render(page, card('doc-query-card').text);
  const out = await page.evaluate(() =>
    window.harness.currentRoot().querySelector('#dq-out').textContent);
  expect(out, 'querySelector/getElementsBy*/forms all resolve in the message')
    .toBe('qs/1/1/1/1');
});

test('INV-MR3 a lookup the message cannot answer still reaches the document', async ({ page }) => {
  await render(page, '<div id="mr3">x</div><script>window.__mr3 = ' +
    "document.getElementById('chat-container') ? 'document' : 'missing';</script>");
  const seen = await page.evaluate(() => window.__mr3);
  expect(seen).toBe('document');
});

test('INV-MR6 a modal handed to document.body stays under the message CSS', async ({ page }) => {
  await render(page, card('doc-body-card').text);
  await page.evaluate(() => window.harness.currentRoot().querySelector('#db-open').click());
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    const modal = root.querySelector('#db-modal');
    return {
      inMessage: !!modal,
      inAppBody: !!document.body.querySelector(':scope > #db-modal'),
      colour: modal ? getComputedStyle(modal).color : '',
      overlay: !!root.querySelector('.glaze-message-overlay'),
    };
  });
  expect(shape.inMessage, 'the modal is in the message, not in the app chrome').toBe(true);
  expect(shape.inAppBody).toBe(false);
  expect(shape.colour, "the card's own rule applies to it").toBe('rgb(9, 90, 200)');
  expect(shape.overlay).toBe(true);
});

test('INV-MR7 the load events a card waits for still arrive', async ({ page }) => {
  await render(page, card('doc-ready-card').text);
  const out = await page.evaluate(() =>
    window.harness.currentRoot().querySelector('#dr-out').textContent);
  expect(out).toBe('готово+load');
});

test('INV-MR5 an @import is hoisted into the document head', async ({ page }) => {
  // `@import` inside a shadow root is ignored by the browser, and a
  // `@font-face` can only be registered from the document — so the sheet is
  // lifted to a <link> in the head, where the card's font can reach it.
  await render(page, card('import-font-card').text);
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    const links = Array.from(document.head.querySelectorAll('link[data-glaze-import]'));
    return {
      hrefs: links.map((l) => l.getAttribute('href')),
      rel: links[0]?.getAttribute('rel'),
      report: root.querySelector('.glaze-css-error')?.textContent || '',
      styleKept: !!root.querySelector('style'),
      titleStyled: getComputedStyle(root.querySelector('.if-title')).fontFamily,
    };
  });
  expect(shape.hrefs).toEqual(['https://fonts.example/css2?family=Card']);
  expect(shape.rel).toBe('stylesheet');
  expect(shape.report, 'a hoisted import is not a problem to report').toBe('');
  expect(shape.styleKept, 'the rest of the card CSS still applies').toBe(true);
  expect(shape.titleStyled).toContain('Card');
});

test('INV-MR5 the same sheet is hoisted once, however many renders', async ({ page }) => {
  const body = card('import-font-card').text;
  await render(page, body);
  await render(page, body);
  await render(page, body, { keep: true });
  const count = await page.evaluate(
    () => document.head.querySelectorAll('link[data-glaze-import]').length,
  );
  expect(count).toBe(1);
});

test('INV-MR5 only https is hoisted; the rest is reported', async ({ page }) => {
  await render(page, card('import-insecure-card').text);
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    return {
      links: document.head.querySelectorAll('link[data-glaze-import]').length,
      report: root.querySelector('.glaze-css-error')?.textContent || '',
      colour: getComputedStyle(root.querySelector('.ii-title')).color,
    };
  });
  expect(shape.links, 'http: and data: are refused').toBe(0);
  expect(shape.report).toContain('@import ignored');
  expect(shape.report).toContain('http://fonts.example/plain.css');
  expect(shape.report).toContain('data:text/css');
  expect(shape.colour, 'the rest of the card CSS still applies').toBe('rgb(3, 4, 5)');
});

test('INV-MR5 an embedded data: @font-face is registered with the document', async ({ page }) => {
  // Chromium ignores @font-face in a shadow-root stylesheet, so the card's
  // own font never applied — and was reported as a network load.
  const body = card('fandom-guide-card').text;
  await render(page, body);
  await render(page, body);
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    const hoisted = Array.from(document.head.querySelectorAll('style[data-glaze-font-face]'));
    return {
      count: hoisted.length,
      onlyFontFaces: hoisted.every((s) => /^@font-face\s*\{[^{}]*\}$/.test(s.textContent.trim())),
      families: Array.from(document.fonts).map((f) => f.family.replace(/"/g, '')),
      report: root.querySelector('.glaze-css-error')?.textContent || '',
    };
  });
  expect(shape.count, 'two faces, each hoisted once').toBe(2);
  expect(shape.onlyFontFaces).toBe(true);
  expect(shape.families).toContain('Shino Larp Display');
  expect(shape.families).toContain('Shino Larp Text');
  expect(shape.report, 'an embedded font is not a problem to report').toBe('');
});

test('INV-MR5 an https @font-face is registered with the document', async ({ page }) => {
  await render(page, card('https-font-face-card').text);
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    const hoisted = Array.from(document.head.querySelectorAll('style[data-glaze-font-face]'));
    return {
      sources: hoisted.map((s) => s.textContent),
      report: root.querySelector('.glaze-css-error')?.textContent || '',
    };
  });
  expect(shape.sources).toHaveLength(1);
  expect(shape.sources[0]).toContain('https://fonts.example/net.woff2');
  expect(shape.report).toBe('');
});

test('INV-MR5 an http @font-face is refused and reported', async ({ page }) => {
  await render(page, card('http-font-face-card').text);
  const shape = await page.evaluate(() => {
    const root = window.harness.currentRoot();
    return {
      hoisted: document.head.querySelectorAll('style[data-glaze-font-face]').length,
      report: root.querySelector('.glaze-css-error')?.textContent || '',
      colour: getComputedStyle(root.querySelector('.pf-title')).color,
    };
  });
  expect(shape.hoisted).toBe(0);
  expect(shape.report).toContain('@font-face "Plain Card Font" ignored');
  expect(shape.colour, 'the rest of the card CSS still applies').toBe('rgb(6, 7, 9)');
});

test('INV-MR2 the app keeps its own document while a message runs', async ({ page }) => {
  await render(page, card('doc-body-card').text);
  const restored = await page.evaluate(() => {
    // Every shim is an own property, removed once the message's code is done.
    const own = ['getElementById', 'querySelector', 'body', 'head', 'forms']
      .filter((name) => Object.prototype.hasOwnProperty.call(document, name));
    return { own, bodyIsBody: document.body === document.querySelector('body') };
  });
  expect(restored.own).toEqual([]);
  expect(restored.bodyIsBody).toBe(true);
});

test('INV-MR8 message scripts stay off when the toggle is off', async ({ page }) => {
  await render(page, card('doc-body-card').text, { allowMessageScripts: false });
  await page.evaluate(() => window.harness.currentRoot().querySelector('#db-open').click());
  const shape = await page.evaluate(() => ({
    modal: !!window.harness.currentRoot().querySelector('#db-modal'),
    scripts: window.harness.currentRoot().querySelectorAll('script').length,
  }));
  expect(shape.modal).toBe(false);
  expect(shape.scripts).toBe(0);
});

test('a card script survives its own comparisons', async ({ page }) => {
  // `i<n; i++) { if (i>` looks exactly like a tag to a scan that works on the
  // message as a string, and escaping it leaves the script unparseable. The
  // scan never sees a <script> body: it is masked for the length of it.
  await render(page, card('script-comparison').text);
  const shape = await page.evaluate((body) => ({
    out: window.harness.currentRoot().querySelector('#sc-out').textContent,
    formatted: window.harness.format(body),
  }), card('script-comparison').text);
  expect(shape.out, 'the script ran').toBe('ok2');
  expect(shape.formatted).toContain('i<n');
  expect(shape.formatted).not.toContain('&lt;n');
});

test('a card script keeps its template literals', async ({ page }) => {
  // The backticks of `${x}` are not inline code: a closed <script> is held
  // before the inline-code pass reads the message.
  await render(page, card('script-template-literal').text);
  const out = await page.evaluate(() =>
    window.harness.currentRoot().querySelector('#tl-out').innerHTML);
  expect(out).toBe('<b>привет, мир</b>!');
  expect(page.__failures).toEqual([]);
});

test('INV-MR1 currentScript describes the element the script was written in', async ({ page }) => {
  await render(page, `<section class="cs-wrap" data-k="w"><span id="cs-prev">a</span><script data-role="probe">
var s = document.currentScript;
window.__cs = {
  prev: s.previousElementSibling && s.previousElementSibling.id,
  next: s.nextElementSibling && s.nextElementSibling.id,
  parent: s.parentElement && s.parentElement.className,
  closest: s.closest('[data-k]') && s.closest('[data-k]').dataset.k,
  role: s.dataset.role,
  attr: s.getAttribute('data-role'),
};
var root = s.getRootNode;
setTimeout(function () { window.__csRoot = root() instanceof ShadowRoot; }, 0);
</script><i id="cs-next">b</i></section>`);
  await page.waitForFunction(() => window.__csRoot !== undefined);
  const shape = await page.evaluate(() => ({ ...window.__cs, root: window.__csRoot }));
  expect(shape).toEqual({
    prev: 'cs-prev',
    next: 'cs-next',
    parent: 'cs-wrap',
    closest: 'w',
    role: 'probe',
    attr: 'probe',
    root: true,
  });
});

test('INV-MR8 a timer a card schedules runs with the message document', async ({ page }) => {
  await render(page, `<div id="tm-out">-</div><script>
setTimeout(function () {
  document.getElementById('tm-out').textContent = 'timeout';
  requestAnimationFrame(function () {
    document.getElementById('tm-out').textContent += '+frame';
  });
}, 0);
</script>`);
  await page.waitForFunction(() =>
    window.harness.currentRoot().querySelector('#tm-out').textContent === 'timeout+frame');
  const own = await page.evaluate(() =>
    ['setTimeout', 'setInterval', 'requestAnimationFrame'].map((name) =>
      window[name] === Window.prototype[name] ||
        String(window[name]).includes('[native code]')));
  expect(own, 'the timers are the browser\'s own once the scope is gone').toEqual([true, true, true]);
});

test('INV-MR8 the app\'s own listeners and timers keep the app\'s document', async ({ page }) => {
  await render(page, `<button id="ap-btn" onclick="setTimeout(function () {
  document.getElementById('ap-out').textContent = 'card';
}, 0)">go</button><div id="ap-out">-</div><script>window.__apReady = 1;</script>`);
  await page.evaluate(() => {
    window.__app = null;
    document.addEventListener('click', () => {
      const inEvent = document.body;
      setTimeout(() => {
        window.__app = {
          inEvent: inEvent === document.querySelector('body'),
          inTimer: document.body === document.querySelector('body') &&
            String(document.getElementById).includes('[native code]'),
        };
      }, 0);
    }, { once: true });
    window.harness.currentRoot().querySelector('#ap-btn').click();
  });
  await page.waitForFunction(() => window.__app !== null);
  const shape = await page.evaluate(() => ({
    app: window.__app,
    card: window.harness.currentRoot().querySelector('#ap-out').textContent,
  }));
  expect(shape.app).toEqual({ inEvent: true, inTimer: true });
  expect(shape.card, 'the card\'s own timer still sees the message').toBe('card');
});
