import 'package:flutter_test/flutter_test.dart';
import 'package:glaze_flutter/core/llm/reasoning_leak_guard.dart';

void main() {
  test('removes closed think-style blocks under any common tag name', () {
    expect(stripLeakedReasoning('<think>plan</think>Hello'), 'Hello');
    expect(stripLeakedReasoning('Hi <thinking>hmm</thinking>there'), 'Hi there');
    expect(stripLeakedReasoning('<REASONING>x</REASONING>ok'), 'ok');
    expect(stripLeakedReasoning('a<scratchpad>\nline\n</scratchpad>b'), 'ab');
  });

  test('an unclosed tag hides everything after it', () {
    expect(stripLeakedReasoning('Fine so far <think>half a tho'), 'Fine so far ');
  });

  test('a stray closing tag is dropped', () {
    expect(stripLeakedReasoning('lost the start</think> and the reply'), 'lost the start and the reply');
  });

  test('plain story text is untouched', () {
    const text = '"Hello," she said. *She thought about it.* <3';
    expect(stripLeakedReasoning(text), text);
  });

  test('extra preset tags are honoured', () {
    expect(
      stripLeakedReasoning('[[a]]secret[[/a]]shown', extraPairs: const [('[[a]]', '[[/a]]')]),
      'shown',
    );
  });
}
