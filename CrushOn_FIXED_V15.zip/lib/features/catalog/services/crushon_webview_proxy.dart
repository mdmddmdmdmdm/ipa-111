import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'crushon_session.dart';

void _log(String m) => debugPrint('[CrushOn-proxy] $m');

/// Persistent offscreen WebView that runs crushon.ai API requests from inside
/// a real browser session.
///
/// **Why this exists.** Cloudflare binds `cf_clearance` to the TLS/JA3
/// fingerprint of the client that solved the challenge. A cookie obtained in a
/// WebView **cannot** be replayed by Dio — the Dart HTTP stack produces a
/// different TLS handshake, so CF answers 403 even with the exact same cookie
/// + User-Agent. Running `fetch()` *inside* the page keeps the same fingerprint
/// and cookie jar, so the request passes. (Same architecture as
/// [JanitorWebViewProxy].)
class CrushOnWebViewProxy {
  CrushOnWebViewProxy._();
  static final CrushOnWebViewProxy instance = CrushOnWebViewProxy._();

  static final WebUri _origin = WebUri('https://crushon.ai');

  HeadlessInAppWebView? _webView;
  InAppWebViewController? _controller;
  Completer<void>? _starting;
  Completer<void>? _loadStop;

  /// Serializes fetches so concurrent catalog calls don't race on start/reload.
  Future<void> _gate = Future<void>.value();

  Future<T> _enqueue<T>(Future<T> Function() job) {
    final done = Completer<T>();
    _gate = _gate.then((_) async {
      try {
        done.complete(await job());
      } catch (e, st) {
        done.completeError(e, st);
      }
    });
    return done.future;
  }

  /// GET/POST [url] from inside the CrushOn page context.
  /// Returns response body text. Throws on CF block or hard failure.
  Future<String> fetch(
    String url, {
    String method = 'GET',
    String? body,
    Map<String, String>? headers,
  }) =>
      _enqueue(() => _fetchLocked(url, method: method, body: body, headers: headers));

  Future<String> _fetchLocked(
    String url, {
    String method = 'GET',
    String? body,
    Map<String, String>? headers,
  }) async {
    await _ensureStarted();

    var result = await _rawFetch(url, method: method, body: body, headers: headers);

    if (_isCfBlocked(result)) {
      _log('CF block on fetch — reloading page to refresh clearance');
      await _reload();
      result = await _rawFetch(url, method: method, body: body, headers: headers);
    }

    if (_isCfBlocked(result)) {
      _log('CF block persists after reload');
      throw Exception(
        'CrushOn is still behind Cloudflare. Open CrushOn sign-in, wait until '
        'the full site loads (not a challenge page), tap Done, then retry.',
      );
    }
    if (result.status < 0) {
      throw Exception('CrushOn WebView request failed');
    }
    if (result.status >= 400) {
      throw Exception('CrushOn HTTP ${result.status}: ${_snip(result.body)}');
    }
    return result.body;
  }

  String _snip(String s) {
    final t = s.trim();
    if (t.length <= 180) return t;
    return '${t.substring(0, 180)}…';
  }

  Future<void> _ensureStarted() {
    if (_controller != null) return Future<void>.value();
    if (_starting != null) return _starting!.future;
    final c = Completer<void>();
    _starting = c;
    _start().then((_) {
      c.complete();
    }).catchError((Object e, StackTrace st) {
      _starting = null;
      c.completeError(e, st);
    });
    return c.future;
  }

  Future<void> _start() async {
    _log('starting headless webview');
    await CrushOnWebSession.instance.ensureLoaded();

    // Seed cookies from the login sheet harvest into the shared cookie jar
    // before the headless view loads, so the first navigation already carries
    // auth + clearance when available.
    await _seedCookiesFromSession();

    final created = Completer<void>();
    _loadStop = Completer<void>();
    final hv = HeadlessInAppWebView(
      initialUrlRequest: URLRequest(url: _origin),
      initialSettings: InAppWebViewSettings(
        javaScriptEnabled: true,
        domStorageEnabled: true,
        databaseEnabled: true,
        cacheEnabled: true,
        thirdPartyCookiesEnabled: true,
        sharedCookiesEnabled: true,
        isInspectable: false,
        useHybridComposition: true,
        userAgent: CrushOnWebSession.instance.userAgent,
      ),
      onWebViewCreated: (controller) async {
        _controller = controller;
        if (!created.isCompleted) created.complete();
      },
      onLoadStop: (controller, url) {
        _log('onLoadStop: $url');
        // Dismiss common CrushOn promo / gift / onboarding modals that appear
        // on first load and obscure the feed.
        controller.evaluateJavascript(source: """
          (function(){
            try {
              document.querySelectorAll("[class*=modal] button, [class*=dialog] button, [class*=popup] button, [class*=overlay] button, [aria-label*=close i], [aria-label*=dismiss i]").forEach(function(b){
                var t = (b.textContent||"").toLowerCase();
                if (t.includes("close") || t.includes("skip") || t.includes("got it") || t.includes("dismiss") || t === "×" || t === "x") {
                  try { b.click(); } catch(e){}
                }
              });
              document.querySelectorAll("[class*=gift], [class*=reward], [class*=promo], [class*=banner], [class*=onboard]").forEach(function(el){
                try { el.style.display = "none"; } catch(e){}
              });
              document.querySelectorAll("button, a").forEach(function(el){
                var t = (el.textContent||"").trim().toLowerCase();
                if (t === "skip" || t === "maybe later" || t === "not now" || t === "close" || t === "got it") {
                  try { el.click(); } catch(e){}
                }
              });
            } catch(e){}
          })();
        """);
        final c = _loadStop;
        if (c != null && !c.isCompleted) c.complete();
      },
    );
    await hv.run();
    _webView = hv;
    await created.future;
    await _awaitLoad();
    await _waitForClearance();
    _log('headless ready');
  }

  Future<void> _seedCookiesFromSession() async {
    final header = CrushOnWebSession.instance.cookieHeader;
    if (header == null || header.isEmpty) return;
    final cm = CookieManager.instance();
    for (final part in header.split(';')) {
      final eq = part.indexOf('=');
      if (eq <= 0) continue;
      final name = part.substring(0, eq).trim();
      final value = part.substring(eq + 1).trim();
      if (name.isEmpty) continue;
      try {
        await cm.setCookie(
          url: _origin,
          name: name,
          value: value,
          domain: 'crushon.ai',
          path: '/',
          isSecure: true,
        );
      } catch (_) {}
    }
    _log('seeded ${header.split(';').length} cookie parts from session');
  }

  Future<void> _awaitLoad() async {
    final c = _loadStop;
    if (c == null) return;
    try {
      await c.future.timeout(const Duration(seconds: 30));
    } on TimeoutException {
      _log('load timeout — continuing anyway');
    }
  }

  Future<void> _reload() async {
    final controller = _controller;
    if (controller == null) return;
    _loadStop = Completer<void>();
    try {
      await controller.loadUrl(urlRequest: URLRequest(url: _origin));
    } catch (e) {
      _log('reload error: $e');
    }
    await _awaitLoad();
    await _waitForClearance();
  }

  Future<bool> _waitForClearance() async {
    final deadline = DateTime.now().add(const Duration(seconds: 12));
    while (DateTime.now().isBefore(deadline)) {
      try {
        final cookies =
            await CookieManager.instance().getCookies(url: _origin);
        for (final c in cookies) {
          if (c.name == 'cf_clearance') {
            final value = c.value.toString();
            if (value.isNotEmpty) {
              _log('cf_clearance present');
              // Keep session cache in sync for UI / account state.
              final parts = cookies
                  .where((x) => x.value.toString().isNotEmpty)
                  .map((x) => '${x.name}=${x.value}')
                  .join('; ');
              await CrushOnWebSession.instance.setFromWebView(
                cookieHeader: parts,
                userAgent: CrushOnWebSession.instance.userAgent,
              );
              return true;
            }
          }
        }
      } catch (_) {}
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    _log('cf_clearance NOT obtained within timeout (may still work)');
    return false;
  }

  Future<({int status, String body})> _rawFetch(
    String url, {
    String method = 'GET',
    String? body,
    Map<String, String>? headers,
  }) async {
    final controller = _controller;
    if (controller == null) return (status: -1, body: '');
    _log('rawFetch $method → ${url.length > 100 ? url.substring(0, 100) : url}');

    final headerMap = <String, String>{
      'Accept': 'application/json, text/plain, */*',
      'x-nsfw': 'true',
      'x-gender': '0',
      'x-language': 'en',
      ...?headers,
    };

    try {
      final res = await controller
          .callAsyncJavaScript(
            functionBody: '''
              const headers = ${jsonEncode(headerMap)};
              const opts = {
                method: ${jsonEncode(method)},
                headers: headers,
                credentials: "include",
              };
              ${body == null ? '' : 'opts.body = ${jsonEncode(body)}; if (!headers["Content-Type"]) headers["Content-Type"] = "application/json";'}
              const r = await fetch(${jsonEncode(url)}, opts);
              const respBody = await r.text();
              return { status: r.status, body: respBody };
            ''',
          )
          .timeout(const Duration(seconds: 30));
      if (res == null || res.error != null) {
        _log('rawFetch JS error: ${res?.error}');
        return (status: -1, body: '');
      }
      final value = res.value;
      if (value is Map) {
        final status = (value['status'] as num?)?.toInt() ?? -1;
        final respBody = value['body']?.toString() ?? '';
        _log('rawFetch ← status=$status bytes=${respBody.length}');
        return (status: status, body: respBody);
      }
      return (status: -1, body: '');
    } on TimeoutException {
      _log('rawFetch TIMEOUT');
      return (status: -1, body: '');
    } catch (e) {
      _log('rawFetch exception: $e');
      return (status: -1, body: '');
    }
  }

  bool _isCfBlocked(({int status, String body}) r) {
    if (r.status == 403 || r.status == 503) return true;
    final lower = r.body.toLowerCase();
    if (lower.contains('just a moment') ||
        lower.contains('cf-browser-verification') ||
        lower.contains('challenge-platform') ||
        lower.contains('cdn-cgi/challenge')) {
      return true;
    }
    return false;
  }

  /// Call after login sheet harvest so the next fetch reuses fresh cookies.
  Future<void> invalidate() async {
    _log('invalidate — disposing headless so next fetch restarts clean');
    await dispose();
  }

  Future<void> dispose() async {
    final webView = _webView;
    _webView = null;
    _controller = null;
    _starting = null;
    _loadStop = null;
    try {
      await webView?.dispose();
    } catch (_) {}
  }
}
